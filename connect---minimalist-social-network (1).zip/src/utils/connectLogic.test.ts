import test from 'node:test';
import assert from 'node:assert/strict';
import {
  formatPostTimestamp,
  getVerificationTick,
  isPostEditable,
  generateShareableLink,
  handleLikeTap,
  handleSuperLikeDoubleTap,
} from './connectLogic.ts';

test('formatPostTimestamp - today shows exact time HH:MM', () => {
  const ref = new Date('2026-10-31T15:45:00Z');
  const postDate = new Date('2026-10-31T09:30:00Z');
  const formatted = formatPostTimestamp(postDate, ref);
  assert.match(formatted, /^\d{2}:\d{2}$/);
});

test('formatPostTimestamp - yesterday shows "Yesterday"', () => {
  const ref = new Date('2026-10-31T15:45:00Z');
  const postDate = new Date('2026-10-30T14:20:00Z');
  const formatted = formatPostTimestamp(postDate, ref);
  assert.equal(formatted, 'Yesterday');
});

test('formatPostTimestamp - older date shows full date Month Day, Year', () => {
  const ref = new Date('2026-10-31T15:45:00Z');
  const postDate = new Date('2026-08-15T10:00:00Z');
  const formatted = formatPostTimestamp(postDate, ref);
  assert.match(formatted, /Aug \d{1,2}, 2026/);
});

test('getVerificationTick - dynamic hierarchy based on stats', () => {
  // < 100 hours, < 50 connections -> none
  assert.equal(
    getVerificationTick({ activeUsageHours: 40, connectionsCount: 15, totalPostViews: 200 }),
    'none'
  );

  // >= 100 hours -> blue tick
  assert.equal(
    getVerificationTick({ activeUsageHours: 105, connectionsCount: 20, totalPostViews: 200 }),
    'blue'
  );

  // >= 50 connections -> yellow tick (community milestone)
  assert.equal(
    getVerificationTick({ activeUsageHours: 105, connectionsCount: 55, totalPostViews: 200 }),
    'yellow'
  );

  // top creator -> red tick
  assert.equal(
    getVerificationTick({ activeUsageHours: 150, connectionsCount: 60, totalPostViews: 1200, isTopCreator: true }),
    'red'
  );

  // >= 1000 views + >= 50 connections + >= 100 hours -> red tick
  assert.equal(
    getVerificationTick({ activeUsageHours: 120, connectionsCount: 75, totalPostViews: 1500 }),
    'red'
  );
});

test('isPostEditable - 1 hour window enforcement', () => {
  const now = new Date('2026-10-31T12:00:00Z');
  
  // 30 minutes ago -> editable
  const post30MinAgo = new Date('2026-10-31T11:30:00Z');
  assert.equal(isPostEditable(post30MinAgo, now), true);

  // 59 minutes ago -> editable
  const post59MinAgo = new Date('2026-10-31T11:01:00Z');
  assert.equal(isPostEditable(post59MinAgo, now), true);

  // 61 minutes ago -> NOT editable
  const post61MinAgo = new Date('2026-10-31T10:59:00Z');
  assert.equal(isPostEditable(post61MinAgo, now), false);

  // 2 days ago -> NOT editable
  const postOld = new Date('2026-10-29T10:00:00Z');
  assert.equal(isPostEditable(postOld, now), false);
});

test('generateShareableLink - returns canonical URL structure', () => {
  const link = generateShareableLink('post-789');
  assert.equal(link, 'https://connect.social/p/post-789');
});

test('handleLikeTap and handleSuperLikeDoubleTap state transitions', () => {
  // Tap from none -> blue
  const tap1 = handleLikeTap('none');
  assert.equal(tap1.nextState, 'blue');
  assert.equal(tap1.deltaLikes, 1);

  // Tap from blue -> none
  const tap2 = handleLikeTap('blue');
  assert.equal(tap2.nextState, 'none');
  assert.equal(tap2.deltaLikes, -1);

  // Double tap from none -> red (Super Like)
  const dblTap1 = handleSuperLikeDoubleTap('none');
  assert.equal(dblTap1.nextState, 'red');
  assert.equal(dblTap1.deltaLikes, 1);

  // Double tap from blue -> red (Super Like upgrade)
  const dblTap2 = handleSuperLikeDoubleTap('blue');
  assert.equal(dblTap2.nextState, 'red');
  assert.equal(dblTap2.deltaLikes, 0);
});
