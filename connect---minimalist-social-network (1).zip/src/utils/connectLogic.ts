/**
 * Pure business logic for Connect social networking app
 * Handles timestamps, verification ticks, post edit constraints, and like states.
 */

export type VerificationType = 'none' | 'blue' | 'yellow' | 'red';
export type LikeState = 'none' | 'blue' | 'red';

export interface UserStats {
  activeUsageHours: number;
  connectionsCount: number;
  totalPostViews: number;
  isTopCreator?: boolean;
}

/**
 * Format timestamp according to strict specification:
 * - Exact time if posted today (e.g., "14:30")
 * - "Yesterday" if posted yesterday
 * - Full Date if older (e.g., "Oct 15, 2026")
 */
export function formatPostTimestamp(dateInput: Date | string | number, referenceDate: Date = new Date()): string {
  const postDate = new Date(dateInput);
  if (isNaN(postDate.getTime())) {
    return 'Just now';
  }

  const isSameDay =
    postDate.getFullYear() === referenceDate.getFullYear() &&
    postDate.getMonth() === referenceDate.getMonth() &&
    postDate.getDate() === referenceDate.getDate();

  if (isSameDay) {
    const hours = postDate.getHours().toString().padStart(2, '0');
    const minutes = postDate.getMinutes().toString().padStart(2, '0');
    return `${hours}:${minutes}`;
  }

  const yesterday = new Date(referenceDate);
  yesterday.setDate(referenceDate.getDate() - 1);
  const isYesterday =
    postDate.getFullYear() === yesterday.getFullYear() &&
    postDate.getMonth() === yesterday.getMonth() &&
    postDate.getDate() === yesterday.getDate();

  if (isYesterday) {
    return 'Yesterday';
  }

  const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  const month = months[postDate.getMonth()];
  const day = postDate.getDate();
  const year = postDate.getFullYear();
  return `${month} ${day}, ${year}`;
}

/**
 * Calculate dynamic verification tick based on user engagement:
 * - Red Tick (Top Level): Ultimate badge for top creators and active collaborators (isTopCreator or >= 1000 views with milestones).
 * - Yellow Tick: Higher community connection milestones (>= 50 connections).
 * - Blue Tick: Unlocked after 100 hours of active app scrolling/usage.
 * - None: If criteria not met.
 */
export function getVerificationTick(stats: UserStats): VerificationType {
  if (stats.isTopCreator || (stats.totalPostViews >= 1000 && stats.connectionsCount >= 50 && stats.activeUsageHours >= 100)) {
    return 'red';
  }
  if (stats.connectionsCount >= 50) {
    return 'yellow';
  }
  if (stats.activeUsageHours >= 100) {
    return 'blue';
  }
  return 'none';
}

/**
 * Check if a post is within the 1-hour editable window.
 */
export function isPostEditable(createdAt: Date | string | number, currentTime: Date = new Date()): boolean {
  const postTime = new Date(createdAt).getTime();
  const now = currentTime.getTime();
  const ONE_HOUR_MS = 60 * 60 * 1000;
  return now - postTime <= ONE_HOUR_MS && now >= postTime;
}

/**
 * Generate canonical shareable link structure for a post.
 */
export function generateShareableLink(postId: string, baseUrl: string = 'https://connect.social'): string {
  return `${baseUrl}/p/${postId}`;
}

/**
 * State machine for like / super like interactions:
 * - single tap: toggles between 'none' and 'blue' (or if red, toggles to none)
 * - double tap: transitions directly to 'red' (Super Like)
 */
export function handleLikeTap(currentState: LikeState): { nextState: LikeState; deltaLikes: number } {
  if (currentState === 'none') {
    return { nextState: 'blue', deltaLikes: 1 };
  } else {
    return { nextState: 'none', deltaLikes: -1 };
  }
}

export function handleSuperLikeDoubleTap(currentState: LikeState): { nextState: LikeState; deltaLikes: number } {
  if (currentState === 'red') {
    // Already super liked, refresh or keep
    return { nextState: 'red', deltaLikes: 0 };
  } else if (currentState === 'blue') {
    return { nextState: 'red', deltaLikes: 0 };
  } else {
    return { nextState: 'red', deltaLikes: 1 };
  }
}
