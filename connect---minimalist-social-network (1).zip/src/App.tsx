import React, { useState, useEffect } from 'react';
import { User, Post, Story, Achievement, Conversation, CommentItem } from './types';
import {
  CURRENT_USER,
  INITIAL_POSTS,
  INITIAL_STORIES,
  INITIAL_ACHIEVEMENTS,
  INITIAL_CONVERSATIONS,
} from './data/mockData';
import { handleLikeTap, handleSuperLikeDoubleTap, generateShareableLink } from './utils/connectLogic';
import { StoriesCarousel } from './components/StoriesCarousel';
import { StoryViewerModal } from './components/StoryViewerModal';
import { PostCard } from './components/PostCard';
import { SponsoredAdCard } from './components/SponsoredAdCard';
import { ThreadedCommentModal } from './components/ThreadedCommentModal';
import { CreatePostModal } from './components/CreatePostModal';
import { EditPostModal } from './components/EditPostModal';
import { ProfileView } from './components/ProfileView';
import { MessagesView } from './components/MessagesView';
import { PostInsightsModal } from './components/PostInsightsModal';
import { AchievementsModal } from './components/AchievementsModal';
import { SettingsModal } from './components/SettingsModal';
import { InfoModals } from './components/InfoModals';
import { FlutterCodeViewerModal } from './components/FlutterCodeViewerModal';
import {
  Home,
  MessageCircle,
  User as UserIcon,
  PlusCircle,
  Code2,
  Smartphone,
  Maximize2,
  Sparkles,
  Link2,
} from 'lucide-react';

export default function App() {
  // Navigation
  const [activeTab, setActiveTab] = useState<'home' | 'messages' | 'profile'>('home');
  const [isPhoneFrame, setIsPhoneFrame] = useState<boolean>(true);
  const [lowSpecMode, setLowSpecMode] = useState<boolean>(false);

  // State
  const [currentUser, setCurrentUser] = useState<User>(CURRENT_USER);
  const [posts, setPosts] = useState<Post[]>(INITIAL_POSTS);
  const [stories, setStories] = useState<Story[]>(INITIAL_STORIES);
  const [achievements, setAchievements] = useState<Achievement[]>(INITIAL_ACHIEVEMENTS);
  const [conversations, setConversations] = useState<Conversation[]>(INITIAL_CONVERSATIONS);

  // Active Modals
  const [activeStoryIdx, setActiveStoryIdx] = useState<number | null>(null);
  const [activeCommentPost, setActiveCommentPost] = useState<Post | null>(null);
  const [activeEditPost, setActiveEditPost] = useState<Post | null>(null);
  const [isCreatePostOpen, setIsCreatePostOpen] = useState<boolean>(false);
  const [isCodeModalOpen, setIsCodeModalOpen] = useState<boolean>(false);
  const [isInsightsOpen, setIsInsightsOpen] = useState<boolean>(false);
  const [isAchievementsOpen, setIsAchievementsOpen] = useState<boolean>(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState<boolean>(false);
  const [infoModalConfig, setInfoModalConfig] = useState<{ isOpen: boolean; title: string; type: 'privacy' | 'about' }>({
    isOpen: false,
    title: '',
    type: 'privacy',
  });

  // Toast feedback
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3000);
  };

  // 1. Post Like Handling (Single Tap -> Blue)
  const handleLikeToggle = (postId: string) => {
    setPosts((prev) =>
      prev.map((p) => {
        if (p.id !== postId) return p;
        const { nextState, deltaLikes } = handleLikeTap(p.userLikeState);
        return {
          ...p,
          userLikeState: nextState,
          likesCount: Math.max(0, p.likesCount + deltaLikes),
        };
      })
    );
  };

  // 2. Post Super Like Handling (Double Tap -> Red Super Like)
  const handleSuperLike = (postId: string) => {
    setPosts((prev) =>
      prev.map((p) => {
        if (p.id !== postId) return p;
        const { nextState, deltaLikes } = handleSuperLikeDoubleTap(p.userLikeState);
        return {
          ...p,
          userLikeState: nextState,
          likesCount: p.likesCount + deltaLikes,
          superLikesCount: p.superLikesCount + 1,
        };
      })
    );
    showToast('Super Like sent! (Double-tap Red burst)');

    // Increment Super Liker progress if applicable
    setAchievements((prev) =>
      prev.map((ach) =>
        ach.id === 'ach_super_liker'
          ? {
              ...ach,
              currentProgress: Math.min(ach.targetProgress, ach.currentProgress + 1),
              isUnlocked: ach.currentProgress + 1 >= ach.targetProgress,
            }
          : ach
      )
    );
  };

  // 3. Post Share Handling
  const handleSharePost = (postId: string) => {
    const link = generateShareableLink(postId);
    navigator.clipboard.writeText(link);
    setPosts((prev) =>
      prev.map((p) => (p.id === postId ? { ...p, sharesCount: p.sharesCount + 1 } : p))
    );
    showToast(`Share link copied: ${link}`);
  };

  // 4. Threaded Comments
  const handleAddComment = (postId: string, text: string, replyToCommentId?: string) => {
    const isAuthor = postId === 'p1' || currentUser.id === 'current_user';
    const newComment: CommentItem = {
      id: `c_${Date.now()}`,
      postId,
      author: {
        id: currentUser.id,
        name: currentUser.name,
        username: currentUser.username,
        avatar: currentUser.avatar,
        creativeField: currentUser.creativeField,
        verification: 'red',
      },
      content: text,
      createdAt: new Date().toISOString(),
      isAuthorReply: isAuthor && Boolean(replyToCommentId),
      replies: [],
    };

    setPosts((prev) =>
      prev.map((post) => {
        if (post.id !== postId) return post;

        if (!replyToCommentId) {
          return {
            ...post,
            comments: [...post.comments, newComment],
          };
        } else {
          // Find target comment and append reply
          const updateReplies = (list: CommentItem[]): CommentItem[] => {
            return list.map((item) => {
              if (item.id === replyToCommentId) {
                newComment.replyToUsername = item.author.username;
                return {
                  ...item,
                  replies: [...(item.replies || []), newComment],
                };
              }
              if (item.replies && item.replies.length > 0) {
                return {
                  ...item,
                  replies: updateReplies(item.replies),
                };
              }
              return item;
            });
          };

          return {
            ...post,
            comments: updateReplies(post.comments),
          };
        }
      })
    );

    // Keep active post sync
    setActiveCommentPost((prev) => {
      if (!prev || prev.id !== postId) return prev;
      return posts.find((p) => p.id === postId) || prev;
    });

    showToast('Reply published in thread');
  };

  // 5. Post Editing & Deletion
  const handleSaveEditedPost = (postId: string, newContent: string, removeImage?: boolean) => {
    setPosts((prev) =>
      prev.map((p) => {
        if (p.id !== postId) return p;
        return {
          ...p,
          content: newContent,
          image: removeImage ? undefined : p.image,
        };
      })
    );
    showToast('Post updated successfully');
  };

  const handleDeletePost = (postId: string) => {
    setPosts((prev) => prev.filter((p) => p.id !== postId));
    showToast('Post permanently deleted');
  };

  // 6. Create New Post
  const handleCreatePost = (content: string, image?: string) => {
    const newPost: Post = {
      id: `p_${Date.now()}`,
      author: currentUser,
      content,
      image,
      createdAt: new Date().toISOString(),
      likesCount: 0,
      superLikesCount: 0,
      userLikeState: 'none',
      comments: [],
      sharesCount: 0,
      viewsCount: 1,
    };

    setPosts([newPost, ...posts]);
    showToast('New post published to feed');
  };

  // 7. Direct Messages
  const handleSendMessage = (conversationId: string, text: string) => {
    const nowStr = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    const newMsg = {
      id: `m_${Date.now()}`,
      senderId: currentUser.id,
      text,
      timestamp: nowStr,
    };

    setConversations((prev) =>
      prev.map((c) => {
        if (c.id !== conversationId) return c;
        return {
          ...c,
          lastMessage: text,
          lastTime: nowStr,
          messages: [...c.messages, newMsg],
        };
      })
    );

    // Simulated auto-reply from creator after 1.5s
    setTimeout(() => {
      const replyMsg = {
        id: `reply_${Date.now()}`,
        senderId: 'sarah_chen',
        text: 'Thanks for connecting! Loving the minimalist interface and 60fps performance.',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };
      setConversations((prev) =>
        prev.map((c) => {
          if (c.id !== conversationId) return c;
          return {
            ...c,
            lastMessage: replyMsg.text,
            lastTime: replyMsg.timestamp,
            messages: [...c.messages, replyMsg],
          };
        })
      );
    }, 1500);
  };

  // Synchronize comment modal when posts change
  const currentCommentPost = activeCommentPost ? posts.find((p) => p.id === activeCommentPost.id) || activeCommentPost : null;

  return (
    <div className="min-h-screen bg-[#07080c] text-slate-100 flex flex-col items-center">
      {/* Top Universal Applet Bar */}
      <header className="w-full bg-[#0d0f17] border-b border-slate-800/80 px-4 py-2.5 flex items-center justify-between text-xs z-30">
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-lg bg-sky-500/20 border border-sky-500/40 flex items-center justify-center text-sky-400 font-extrabold text-sm">
              C
            </div>
            <div>
              <span className="font-extrabold text-white text-sm tracking-tight">Connect</span>
              <span className="text-[10px] text-slate-400 block font-mono">Mobile Social Network</span>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {/* Flutter Codebase Viewer Toggle */}
          <button
            onClick={() => setIsCodeModalOpen(true)}
            className="px-3 py-1.5 rounded-lg bg-sky-500/15 hover:bg-sky-500/25 text-sky-400 border border-sky-500/30 font-semibold flex items-center gap-1.5 transition-colors shadow-xs"
          >
            <Code2 size={14} />
            <span className="hidden sm:inline">Flutter / Dart Code Hub</span>
            <span className="sm:hidden">Dart Code</span>
          </button>

          {/* Device Frame Viewport Toggle */}
          <button
            onClick={() => setIsPhoneFrame(!isPhoneFrame)}
            className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors"
            title={isPhoneFrame ? 'Switch to Full Screen View' : 'Switch to Mobile Frame'}
            aria-label="Toggle device view"
          >
            {isPhoneFrame ? <Maximize2 size={16} /> : <Smartphone size={16} />}
          </button>
        </div>
      </header>

      {/* Main Container / Mobile Phone Shell */}
      <main className="w-full flex-1 flex justify-center py-0 sm:py-6 px-0 sm:px-4">
        <div
          className={`w-full transition-all duration-300 bg-[#090a0f] relative overflow-hidden flex flex-col ${
            isPhoneFrame
              ? 'max-w-[430px] rounded-none sm:rounded-[36px] border-0 sm:border-[8px] sm:border-slate-850 shadow-2xl min-h-screen sm:min-h-[844px] sm:max-h-[890px]'
              : 'max-w-2xl rounded-none sm:rounded-2xl border-0 sm:border border-slate-800 shadow-xl min-h-screen'
          }`}
        >
          {/* Simulated Mobile Status Bar (when in Phone Frame) */}
          {isPhoneFrame && (
            <div className="hidden sm:flex items-center justify-between px-6 pt-3 pb-1 text-[11px] font-semibold text-slate-400 select-none bg-[#090a0f] z-20">
              <span>9:41</span>
              {/* Dynamic Island / Notch */}
              <div className="w-20 h-4 bg-black rounded-full" />
              <div className="flex items-center gap-1.5 font-mono text-[10px]">
                <span>5G</span>
                <span>100%</span>
              </div>
            </div>
          )}

          {/* Feed Header (Visible on Home Feed) */}
          {activeTab === 'home' && (
            <div className="sticky top-0 bg-[#090a0f]/95 backdrop-blur-md px-4 py-3 border-b border-slate-800/80 flex items-center justify-between z-20">
              <div className="flex items-center gap-2">
                <h1 className="text-xl font-extrabold tracking-tight text-white">Connect</h1>
                <span className="w-2 h-2 rounded-full bg-sky-500 animate-pulse" />
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => setIsCreatePostOpen(true)}
                  aria-label="Create new post"
                  className="px-3 py-1.5 rounded-full bg-sky-500 hover:bg-sky-400 text-slate-950 font-bold text-xs flex items-center gap-1 transition-all shadow-sm active:scale-95"
                >
                  <PlusCircle size={15} />
                  <span>Post</span>
                </button>
              </div>
            </div>
          )}

          {/* Scrollable View Content */}
          <div className="flex-1 overflow-y-auto no-scrollbar">
            {/* 1. HOME FEED */}
            {activeTab === 'home' && (
              <div>
                {/* Stories Row / Carousel */}
                <StoriesCarousel
                  stories={stories}
                  currentUser={currentUser}
                  onOpenStory={(idx) => setActiveStoryIdx(idx)}
                  onAddStory={() => {
                    showToast('Story camera opened');
                    setActiveStoryIdx(0);
                  }}
                />

                {/* Posts & Native Sponsored Ads Feed */}
                <div className="divide-y divide-slate-800/60 pb-16">
                  {posts.map((post) => {
                    if (post.isSponsored) {
                      return (
                        <SponsoredAdCard
                          key={post.id}
                          post={post}
                          onOpenComments={(p) => setActiveCommentPost(p)}
                          onSharePost={handleSharePost}
                        />
                      );
                    }
                    return (
                      <PostCard
                        key={post.id}
                        post={post}
                        currentUser={currentUser}
                        onLikeToggle={handleLikeToggle}
                        onSuperLike={handleSuperLike}
                        onOpenComments={(p) => setActiveCommentPost(p)}
                        onEditPost={(p) => setActiveEditPost(p)}
                        onDeletePost={handleDeletePost}
                        onSharePost={handleSharePost}
                      />
                    );
                  })}
                </div>
              </div>
            )}

            {/* 2. MESSAGES / INBOX */}
            {activeTab === 'messages' && (
              <MessagesView
                conversations={conversations}
                currentUser={currentUser}
                onSendMessage={handleSendMessage}
              />
            )}

            {/* 3. PROFILE */}
            {activeTab === 'profile' && (
              <ProfileView
                user={currentUser}
                achievements={achievements}
                userPosts={posts.filter((p) => p.author.id === currentUser.id)}
                onUpdateUser={(updated) => setCurrentUser(updated)}
                onOpenSettings={() => setIsSettingsOpen(true)}
                onOpenInsights={() => setIsInsightsOpen(true)}
                onOpenAchievementsList={() => setIsAchievementsOpen(true)}
                onOpenPrivacy={() =>
                  setInfoModalConfig({
                    isOpen: true,
                    title: 'Privacy Policy',
                    type: 'privacy',
                  })
                }
                onOpenAbout={() =>
                  setInfoModalConfig({
                    isOpen: true,
                    title: 'About Connect',
                    type: 'about',
                  })
                }
                onSignOut={() => showToast('Signed out (session reset)')}
              />
            )}
          </div>

          {/* Clean Bottom Navigation Bar */}
          <nav
            aria-label="Main Navigation"
            className="sticky bottom-0 bg-[#0d0f18]/95 backdrop-blur-md border-t border-slate-800/90 px-6 py-2.5 flex items-center justify-around z-20"
          >
            <button
              onClick={() => setActiveTab('home')}
              className={`flex flex-col items-center gap-1 transition-colors ${
                activeTab === 'home' ? 'text-sky-400' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Home size={21} strokeWidth={activeTab === 'home' ? 2.5 : 2} />
              <span className="text-[10px] font-semibold">Home</span>
            </button>

            <button
              onClick={() => setActiveTab('messages')}
              className={`relative flex flex-col items-center gap-1 transition-colors ${
                activeTab === 'messages' ? 'text-sky-400' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <MessageCircle size={21} strokeWidth={activeTab === 'messages' ? 2.5 : 2} />
              <span className="text-[10px] font-semibold">Messages</span>
              {/* Unread indicator badge */}
              <span className="absolute -top-1 right-2.5 w-2 h-2 rounded-full bg-sky-400 ring-2 ring-[#0d0f18]" />
            </button>

            <button
              onClick={() => setActiveTab('profile')}
              className={`flex flex-col items-center gap-1 transition-colors ${
                activeTab === 'profile' ? 'text-sky-400' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <UserIcon size={21} strokeWidth={activeTab === 'profile' ? 2.5 : 2} />
              <span className="text-[10px] font-semibold">Profile</span>
            </button>
          </nav>
        </div>
      </main>

      {/* Floating Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-20 z-50 px-4 py-2 bg-slate-900 text-slate-100 text-xs font-semibold rounded-full border border-slate-700 shadow-2xl flex items-center gap-2 animate-in fade-in slide-in-from-bottom-2 duration-150">
          <Sparkles size={14} className="text-sky-400" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Story Viewer Modal */}
      {activeStoryIdx !== null && (
        <StoryViewerModal
          isOpen={activeStoryIdx !== null}
          onClose={() => setActiveStoryIdx(null)}
          stories={stories}
          initialIndex={activeStoryIdx}
        />
      )}

      {/* Threaded Comment Modal */}
      {currentCommentPost && (
        <ThreadedCommentModal
          isOpen={Boolean(currentCommentPost)}
          onClose={() => setActiveCommentPost(null)}
          post={currentCommentPost}
          currentUser={currentUser}
          onAddComment={handleAddComment}
        />
      )}

      {/* Create Post Modal */}
      {isCreatePostOpen && (
        <CreatePostModal
          isOpen={isCreatePostOpen}
          onClose={() => setIsCreatePostOpen(false)}
          currentUser={currentUser}
          onCreatePost={handleCreatePost}
        />
      )}

      {/* Edit Post Modal (with 1-Hour Constraint) */}
      {activeEditPost && (
        <EditPostModal
          isOpen={Boolean(activeEditPost)}
          onClose={() => setActiveEditPost(null)}
          post={activeEditPost}
          onSave={handleSaveEditedPost}
        />
      )}

      {/* Post Insights Modal */}
      <PostInsightsModal
        isOpen={isInsightsOpen}
        onClose={() => setIsInsightsOpen(false)}
        user={currentUser}
        userPosts={posts.filter((p) => p.author.id === currentUser.id)}
      />

      {/* Achievements List Modal */}
      <AchievementsModal
        isOpen={isAchievementsOpen}
        onClose={() => setIsAchievementsOpen(false)}
        achievements={achievements}
      />

      {/* Settings Modal */}
      <SettingsModal
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        lowSpecMode={lowSpecMode}
        onToggleLowSpecMode={(val) => setLowSpecMode(val)}
      />

      {/* Info Modals (Privacy & About) */}
      <InfoModals
        isOpen={infoModalConfig.isOpen}
        onClose={() => setInfoModalConfig({ ...infoModalConfig, isOpen: false })}
        title={infoModalConfig.title}
        type={infoModalConfig.type}
      />

      {/* Complete Flutter & Dart Codebase Hub Modal */}
      <FlutterCodeViewerModal
        isOpen={isCodeModalOpen}
        onClose={() => setIsCodeModalOpen(false)}
      />
    </div>
  );
}
