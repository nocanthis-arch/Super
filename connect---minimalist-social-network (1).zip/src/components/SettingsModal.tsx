import React, { useState } from 'react';
import { X, Cpu, Bell, Shield, Moon, Smartphone } from 'lucide-react';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  lowSpecMode: boolean;
  onToggleLowSpecMode: (val: boolean) => void;
}

export const SettingsModal: React.FC<Props> = ({
  isOpen,
  onClose,
  lowSpecMode,
  onToggleLowSpecMode,
}) => {
  const [notifications, setNotifications] = useState(true);
  const [dataSaver, setDataSaver] = useState(false);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-xs">
      <div
        className="w-full max-w-sm bg-[#11131b] border border-slate-800 rounded-2xl p-5 shadow-2xl space-y-4"
        role="dialog"
        aria-modal="true"
      >
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <h3 className="font-bold text-sm text-slate-100">Connect Settings</h3>
          <button
            onClick={onClose}
            aria-label="Close settings"
            className="p-1 text-slate-400 hover:text-slate-100 rounded-lg hover:bg-slate-800 transition-colors"
          >
            <X size={18} />
          </button>
        </div>

        {/* Low Spec Optimization Toggle */}
        <div className="p-3 bg-slate-900/80 rounded-xl border border-slate-800">
          <div className="flex items-start justify-between gap-3">
            <div className="flex items-start gap-2.5">
              <Cpu size={16} className="text-sky-400 shrink-0 mt-0.5" />
              <div>
                <h4 className="font-bold text-xs text-white">Low-Spec Performance Mode</h4>
                <p className="text-[11px] text-slate-400 mt-0.5 leading-relaxed">
                  Disables heavy backdrop blurs and particle physics to lock 60fps on 2GB RAM devices.
                </p>
              </div>
            </div>
            <input
              type="checkbox"
              checked={lowSpecMode}
              onChange={(e) => onToggleLowSpecMode(e.target.checked)}
              className="mt-1 h-4 w-4 rounded text-sky-500 accent-sky-500 cursor-pointer"
            />
          </div>
        </div>

        {/* Notifications */}
        <div className="p-3 bg-slate-900/60 rounded-xl border border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <Bell size={16} className="text-slate-400" />
            <span className="text-xs text-slate-200">Push Notifications</span>
          </div>
          <input
            type="checkbox"
            checked={notifications}
            onChange={(e) => setNotifications(e.target.checked)}
            className="h-4 w-4 rounded text-sky-500 accent-sky-500 cursor-pointer"
          />
        </div>

        {/* Data Saver */}
        <div className="p-3 bg-slate-900/60 rounded-xl border border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <Smartphone size={16} className="text-slate-400" />
            <span className="text-xs text-slate-200">Data Saver Mode</span>
          </div>
          <input
            type="checkbox"
            checked={dataSaver}
            onChange={(e) => setDataSaver(e.target.checked)}
            className="h-4 w-4 rounded text-sky-500 accent-sky-500 cursor-pointer"
          />
        </div>

        <button
          onClick={onClose}
          className="w-full py-2 bg-sky-500 text-slate-950 font-bold text-xs rounded-xl hover:bg-sky-400 transition-colors"
        >
          Save & Close
        </button>
      </div>
    </div>
  );
};
