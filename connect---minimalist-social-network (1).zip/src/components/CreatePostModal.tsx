import React, { useState } from 'react';
import { User, CreativeField } from '../types';
import { X, Image as ImageIcon, Sparkles, Send } from 'lucide-react';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  currentUser: User;
  onCreatePost: (content: string, image?: string) => void;
}

const SAMPLE_IMAGES = [
  'https://images.unsplash.com/photo-1518770660439-4636190af475?w=800&auto=format&fit=crop&q=80',
  'https://images.unsplash.com/photo-1550745165-9bc0b252726f?w=800&auto=format&fit=crop&q=80',
  'https://images.unsplash.com/photo-1498050108023-c5249f4df085?w=800&auto=format&fit=crop&q=80',
];

export const CreatePostModal: React.FC<Props> = ({
  isOpen,
  onClose,
  currentUser,
  onCreatePost,
}) => {
  const [content, setContent] = useState('');
  const [selectedImage, setSelectedImage] = useState<string | undefined>(undefined);
  const [showImagePicker, setShowImagePicker] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!content.trim()) return;

    onCreatePost(content.trim(), selectedImage);
    setContent('');
    setSelectedImage(undefined);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-xs">
      <div
        className="w-full max-w-md bg-[#11131b] border border-slate-800 rounded-2xl p-5 shadow-2xl relative"
        role="dialog"
        aria-modal="true"
      >
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <Sparkles size={16} className="text-sky-400" />
            <h3 className="font-bold text-sm text-slate-100">Create Post</h3>
          </div>
          <button
            onClick={onClose}
            aria-label="Close create post dialog"
            className="p-1 text-slate-400 hover:text-slate-100 rounded-lg hover:bg-slate-800 transition-colors"
          >
            <X size={18} />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="mt-4 space-y-4">
          <div className="flex items-start gap-3">
            <img
              src={currentUser.avatar}
              alt=""
              className="w-8 h-8 rounded-full object-cover shrink-0 ring-1 ring-slate-800"
            />
            <div className="flex-1">
              <span className="font-semibold text-xs text-slate-200">{currentUser.name}</span>
              <span className="text-[11px] text-slate-500 block">Posting as {currentUser.creativeField}</span>
            </div>
          </div>

          <textarea
            rows={4}
            value={content}
            onChange={(e) => setContent(e.target.value)}
            placeholder="What are you creating or exploring today?"
            className="w-full bg-slate-900 border border-slate-800 text-xs text-slate-100 rounded-xl p-3 focus:outline-none focus:border-sky-500 resize-none leading-relaxed placeholder-slate-500"
            autoFocus
          />

          {selectedImage && (
            <div className="relative rounded-xl overflow-hidden border border-slate-800 max-h-40">
              <img src={selectedImage} alt="Attachment" className="w-full h-full object-cover" />
              <button
                type="button"
                onClick={() => setSelectedImage(undefined)}
                className="absolute top-2 right-2 p-1 bg-black/70 hover:bg-black text-white rounded-full transition-colors"
              >
                <X size={14} />
              </button>
            </div>
          )}

          {showImagePicker && !selectedImage && (
            <div className="p-3 bg-slate-900/80 rounded-xl border border-slate-800 space-y-2">
              <span className="text-[11px] font-medium text-slate-400">Choose a photo attachment:</span>
              <div className="grid grid-cols-3 gap-2">
                {SAMPLE_IMAGES.map((img, i) => (
                  <button
                    key={i}
                    type="button"
                    onClick={() => {
                      setSelectedImage(img);
                      setShowImagePicker(false);
                    }}
                    className="h-16 rounded-lg overflow-hidden border border-slate-700 hover:border-sky-400 transition-colors"
                  >
                    <img src={img} alt="sample" className="w-full h-full object-cover" />
                  </button>
                ))}
              </div>
            </div>
          )}

          <div className="flex items-center justify-between pt-2 border-t border-slate-800/80">
            <button
              type="button"
              onClick={() => setShowImagePicker(!showImagePicker)}
              className="text-xs text-slate-400 hover:text-sky-400 font-medium flex items-center gap-1.5 p-1 rounded-md transition-colors"
            >
              <ImageIcon size={16} />
              <span>{selectedImage ? 'Change Image' : 'Add Photo'}</span>
            </button>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={onClose}
                className="px-3 py-1.5 text-xs text-slate-400 hover:text-white font-medium rounded-lg hover:bg-slate-800 transition-colors"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={!content.trim()}
                className="px-4 py-1.5 text-xs font-semibold rounded-lg bg-sky-500 text-slate-950 hover:bg-sky-400 disabled:opacity-40 flex items-center gap-1.5 transition-colors"
              >
                <Send size={12} />
                <span>Publish</span>
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};
