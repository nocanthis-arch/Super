import React, { useState } from 'react';
import { Post } from '../types';
import { Heart, MessageCircle, Share2, Eye, ExternalLink, Play } from 'lucide-react';

interface Props {
  post: Post;
  onOpenComments: (post: Post) => void;
  onSharePost: (postId: string) => void;
}

export const SponsoredAdCard: React.FC<Props> = ({
  post,
  onOpenComments,
  onSharePost,
}) => {
  const [isLiked, setIsLiked] = useState(false);
  const [likesCount, setLikesCount] = useState(post.likesCount);
  const [isPlayingVideo, setIsPlayingVideo] = useState(false);

  const ad = post.sponsoredData;
  if (!ad) return null;

  const handleLike = () => {
    setIsLiked(!isLiked);
    setLikesCount(isLiked ? likesCount - 1 : likesCount + 1);
  };

  const totalCommentCount = post.comments.reduce(
    (acc, curr) => acc + 1 + (curr.replies ? curr.replies.length : 0),
    0
  );

  return (
    <article className="border-b border-slate-800/80 bg-[#0e111a] p-4 relative">
      {/* Ad Header */}
      <div className="flex items-center justify-between gap-3">
        <div className="flex items-center gap-2.5">
          <img
            src={ad.companyLogo}
            alt={ad.companyName}
            className="w-10 h-10 rounded-xl object-cover ring-1 ring-slate-700/60"
          />
          <div>
            <div className="flex items-center gap-1.5">
              <span className="font-bold text-sm text-slate-100">{ad.companyName}</span>
              <span className="text-[10px] uppercase font-bold text-sky-400 bg-sky-500/10 px-1.5 py-0.2 rounded border border-sky-500/20">
                {ad.format}
              </span>
            </div>
            <div className="text-[11px] font-medium text-slate-400 flex items-center gap-1">
              <span>Sponsored</span>
              <span>·</span>
              <span className="text-slate-500">Promoted</span>
            </div>
          </div>
        </div>

        <a
          href={ad.ctaUrl}
          target="_blank"
          rel="noopener noreferrer"
          className="px-3 py-1 rounded-lg bg-slate-850 hover:bg-slate-800 text-sky-400 border border-slate-700 text-xs font-semibold flex items-center gap-1 transition-colors"
        >
          <span>{ad.ctaText}</span>
          <ExternalLink size={12} />
        </a>
      </div>

      {/* Ad Content */}
      <div className="mt-3 text-slate-200 text-sm leading-relaxed whitespace-pre-wrap">
        {post.content}
      </div>

      {/* Ad Media (Photo or Video format) */}
      {ad.mediaUrl && (
        <div className="mt-3 rounded-xl overflow-hidden border border-slate-800 relative bg-black max-h-80 group">
          <img
            src={ad.mediaUrl}
            alt="Sponsored showcase"
            className="w-full h-full object-cover max-h-80"
          />
          {ad.format === 'video' && (
            <div className="absolute inset-0 bg-black/40 flex items-center justify-center">
              <button
                type="button"
                onClick={() => setIsPlayingVideo(!isPlayingVideo)}
                className="w-12 h-12 rounded-full bg-sky-500/90 hover:bg-sky-400 text-slate-950 flex items-center justify-center shadow-lg transition-transform hover:scale-105"
                aria-label="Play sponsored video"
              >
                <Play size={20} fill="currentColor" className="ml-0.5" />
              </button>
            </div>
          )}
        </div>
      )}

      {/* Interaction Bar: Standard Like, Comment, and Share */}
      <div className="mt-4 pt-2 border-t border-slate-800/60 flex items-center justify-between text-xs text-slate-400">
        <button
          onClick={handleLike}
          aria-label={isLiked ? 'Unlike sponsored ad' : 'Like sponsored ad'}
          className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-full transition-colors ${
            isLiked ? 'text-sky-400 bg-sky-500/10' : 'hover:text-slate-200 hover:bg-slate-800/50'
          }`}
        >
          <Heart size={17} fill={isLiked ? '#38bdf8' : 'none'} />
          <span className="font-medium">{likesCount}</span>
        </button>

        <button
          onClick={() => onOpenComments(post)}
          aria-label="Comment on sponsored ad"
          className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-full hover:text-slate-200 hover:bg-slate-800/50 transition-colors"
        >
          <MessageCircle size={17} />
          <span className="font-medium">{totalCommentCount}</span>
        </button>

        <button
          onClick={() => onSharePost(post.id)}
          aria-label="Share sponsored ad"
          className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-full hover:text-slate-200 hover:bg-slate-800/50 transition-colors"
        >
          <Share2 size={17} />
          <span className="font-medium">{post.sharesCount}</span>
        </button>

        <div className="flex items-center gap-1.5 px-2.5 py-1.5 text-slate-500 font-mono text-[11px]">
          <Eye size={15} className="text-slate-600" />
          <span>{post.viewsCount.toLocaleString()}</span>
        </div>
      </div>
    </article>
  );
};
