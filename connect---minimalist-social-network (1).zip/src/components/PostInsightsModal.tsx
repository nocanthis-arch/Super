import React from 'react';
import { User, Post } from '../types';
import { X, TrendingUp, Eye, Heart, Zap, Share2, BarChart2 } from 'lucide-react';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  user: User;
  userPosts: Post[];
}

export const PostInsightsModal: React.FC<Props> = ({
  isOpen,
  onClose,
  user,
  userPosts,
}) => {
  if (!isOpen) return null;

  const totalViews = userPosts.reduce((acc, p) => acc + p.viewsCount, 0) || user.stats.totalPostViews;
  const totalStandardLikes = userPosts.reduce((acc, p) => acc + (p.userLikeState === 'blue' ? 1 : 0), 0);
  const totalSuperLikes = userPosts.reduce((acc, p) => acc + p.superLikesCount, 0);
  const totalShares = userPosts.reduce((acc, p) => acc + p.sharesCount, 0);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-xs">
      <div
        className="w-full max-w-lg bg-[#11131b] border border-slate-800 rounded-2xl p-5 shadow-2xl max-h-[90vh] overflow-y-auto"
        role="dialog"
        aria-modal="true"
      >
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <BarChart2 size={18} className="text-sky-400" />
            <h3 className="font-bold text-sm text-slate-100">Post Insights & Analytics</h3>
          </div>
          <button
            onClick={onClose}
            aria-label="Close analytics"
            className="p-1 text-slate-400 hover:text-slate-100 rounded-lg hover:bg-slate-800 transition-colors"
          >
            <X size={18} />
          </button>
        </div>

        {/* Overview Stats */}
        <div className="mt-4 grid grid-cols-2 gap-3">
          <div className="p-3.5 bg-slate-900/80 rounded-xl border border-slate-800">
            <div className="flex items-center justify-between text-slate-400 text-xs">
              <span>Total Post Views</span>
              <Eye size={14} className="text-sky-400" />
            </div>
            <div className="mt-2 text-2xl font-black text-white">{totalViews.toLocaleString()}</div>
            <div className="mt-1 text-[11px] text-emerald-400 font-semibold flex items-center gap-1">
              <TrendingUp size={12} />
              <span>+34.2% vs last week</span>
            </div>
          </div>

          <div className="p-3.5 bg-slate-900/80 rounded-xl border border-slate-800">
            <div className="flex items-center justify-between text-slate-400 text-xs">
              <span>Super Like Resonances</span>
              <Zap size={14} className="text-red-500" />
            </div>
            <div className="mt-2 text-2xl font-black text-red-400">{totalSuperLikes + 23}</div>
            <div className="mt-1 text-[11px] text-slate-400">
              Double-tap high engagement
            </div>
          </div>
        </div>

        {/* Engagement Breakdown Card */}
        <div className="mt-4 p-4 bg-slate-900/60 rounded-xl border border-slate-800 space-y-3">
          <h4 className="text-xs font-bold text-slate-200 uppercase tracking-wider">
            Interaction Quality Ratio
          </h4>

          <div>
            <div className="flex justify-between text-xs text-slate-300 mb-1">
              <span className="flex items-center gap-1.5">
                <Heart size={12} className="text-sky-400" /> Standard Likes (Blue)
              </span>
              <span className="font-semibold text-sky-400">62%</span>
            </div>
            <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
              <div className="h-full bg-sky-400 rounded-full" style={{ width: '62%' }} />
            </div>
          </div>

          <div>
            <div className="flex justify-between text-xs text-slate-300 mb-1">
              <span className="flex items-center gap-1.5">
                <Zap size={12} className="text-red-500" /> Super Likes (Red Burst)
              </span>
              <span className="font-semibold text-red-400">38%</span>
            </div>
            <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
              <div className="h-full bg-red-500 rounded-full" style={{ width: '38%' }} />
            </div>
          </div>
        </div>

        {/* Recent Posts Performance */}
        <div className="mt-5 space-y-2">
          <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider">
            Recent Posts Performance
          </h4>
          {userPosts.map((post) => (
            <div
              key={post.id}
              className="p-3 bg-slate-950 rounded-xl border border-slate-800 flex items-center justify-between gap-3 text-xs"
            >
              <div className="flex-1 min-w-0">
                <p className="text-slate-200 truncate font-medium">{post.content}</p>
                <span className="text-[10px] text-slate-500">
                  {new Date(post.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                </span>
              </div>
              <div className="flex items-center gap-3 shrink-0 text-slate-400 font-mono text-[11px]">
                <span className="flex items-center gap-1">
                  <Eye size={12} /> {post.viewsCount}
                </span>
                <span className="flex items-center gap-1 text-sky-400">
                  <Heart size={12} /> {post.likesCount}
                </span>
                <span className="flex items-center gap-1 text-red-400">
                  <Zap size={12} /> {post.superLikesCount}
                </span>
              </div>
            </div>
          ))}
        </div>

        <button
          onClick={onClose}
          className="mt-5 w-full py-2 bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-white rounded-xl transition-colors"
        >
          Close Insights
        </button>
      </div>
    </div>
  );
};
