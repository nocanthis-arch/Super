import React from 'react';
import { Story, User } from '../types';
import { Plus } from 'lucide-react';

interface Props {
  stories: Story[];
  currentUser: User;
  onOpenStory: (index: number) => void;
  onAddStory: () => void;
}

export const StoriesCarousel: React.FC<Props> = ({
  stories,
  currentUser,
  onOpenStory,
  onAddStory,
}) => {
  return (
    <div className="py-3 px-4 border-b border-slate-800/80 bg-[#0c0e15] overflow-x-auto no-scrollbar">
      <div className="flex items-center gap-3.5 min-w-max">
        {/* Current user add story */}
        <div className="flex flex-col items-center gap-1.5 cursor-pointer group" onClick={onAddStory}>
          <div className="relative">
            <img
              src={currentUser.avatar}
              alt="Your story"
              className="w-14 h-14 rounded-full object-cover ring-2 ring-slate-800 group-hover:ring-sky-500 transition-all"
            />
            <span className="absolute bottom-0 right-0 w-4 h-4 bg-sky-500 text-slate-950 rounded-full flex items-center justify-center ring-2 ring-[#0c0e15]">
              <Plus size={11} strokeWidth={3} />
            </span>
          </div>
          <span className="text-[11px] font-medium text-slate-400 group-hover:text-slate-200 transition-colors">
            Your Story
          </span>
        </div>

        {/* Stories from connections */}
        {stories.map((story, idx) => (
          <button
            key={story.id}
            onClick={() => onOpenStory(idx)}
            className="flex flex-col items-center gap-1.5 cursor-pointer group focus:outline-none"
          >
            <div
              className={`p-0.5 rounded-full transition-transform group-hover:scale-105 ${
                story.isViewed
                  ? 'ring-2 ring-slate-700/60'
                  : 'ring-2 ring-sky-500 shadow-[0_0_10px_rgba(56,189,248,0.25)]'
              }`}
            >
              <img
                src={story.user.avatar}
                alt={story.user.name}
                className="w-13 h-13 rounded-full object-cover"
              />
            </div>
            <span className="text-[11px] font-medium text-slate-300 truncate max-w-[62px]">
              {story.user.name.split(' ')[0]}
            </span>
          </button>
        ))}
      </div>
    </div>
  );
};
