import React, { useState } from 'react';
import { Post, CommentItem, User } from '../types';
import { formatPostTimestamp, getVerificationTick } from '../utils/connectLogic';
import { VerificationTick } from './VerificationTick';
import { X, Send, CornerDownRight, MessageSquare } from 'lucide-react';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  post: Post;
  currentUser: User;
  onAddComment: (postId: string, text: string, replyToCommentId?: string) => void;
}

export const ThreadedCommentModal: React.FC<Props> = ({
  isOpen,
  onClose,
  post,
  currentUser,
  onAddComment,
}) => {
  const [inputText, setInputText] = useState('');
  const [replyTarget, setReplyTarget] = useState<CommentItem | null>(null);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim()) return;

    onAddComment(post.id, inputText.trim(), replyTarget?.id);
    setInputText('');
    setReplyTarget(null);
  };

  const renderCommentNode = (comment: CommentItem, depth = 0) => {
    const isAuthor = comment.author.id === post.author.id;

    return (
      <div key={comment.id} className={`group ${depth > 0 ? 'ml-6 pl-3 border-l-2 border-slate-800' : 'mb-4'}`}>
        <div className="flex items-start gap-2.5">
          <img
            src={comment.author.avatar}
            alt={comment.author.name}
            className="w-7 h-7 rounded-full object-cover shrink-0 ring-1 ring-slate-800"
          />
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-1.5 flex-wrap">
              <span className="font-semibold text-xs text-slate-100">{comment.author.name}</span>
              <VerificationTick type={comment.author.verification} size="sm" />
              {isAuthor && (
                <span className="text-[9px] font-bold tracking-wide uppercase px-1.5 py-0.2 bg-sky-500/15 text-sky-400 rounded">
                  Author
                </span>
              )}
              <span className="text-[11px] text-slate-500">@{comment.author.username}</span>
              <span className="text-[11px] text-slate-600">·</span>
              <span className="text-[10px] text-slate-500">{formatPostTimestamp(comment.createdAt)}</span>
            </div>

            {comment.replyToUsername && (
              <div className="text-[11px] text-sky-400 font-medium mt-0.5 flex items-center gap-1">
                <CornerDownRight size={10} />
                <span>Replying to @{comment.replyToUsername}</span>
              </div>
            )}

            <p className="text-xs text-slate-300 mt-1 leading-relaxed break-words">{comment.content}</p>

            <div className="flex items-center gap-3 mt-1.5">
              <button
                type="button"
                onClick={() => setReplyTarget(comment)}
                className="text-[11px] font-medium text-slate-400 hover:text-sky-400 transition-colors flex items-center gap-1"
              >
                Reply
              </button>
            </div>
          </div>
        </div>

        {/* Nested replies */}
        {comment.replies && comment.replies.length > 0 && (
          <div className="mt-3 space-y-3">
            {comment.replies.map((reply) => renderCommentNode(reply, depth + 1))}
          </div>
        )}
      </div>
    );
  };

  const totalCommentCount = post.comments.reduce(
    (acc, curr) => acc + 1 + (curr.replies ? curr.replies.length : 0),
    0
  );

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 bg-black/75 backdrop-blur-xs">
      <div
        className="w-full max-w-lg bg-[#11131b] border border-slate-800 rounded-t-2xl sm:rounded-2xl max-h-[85vh] flex flex-col shadow-2xl overflow-hidden animate-in slide-in-from-bottom-6 duration-200"
        role="dialog"
        aria-modal="true"
      >
        {/* Header */}
        <div className="flex items-center justify-between px-4 py-3 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <MessageSquare size={16} className="text-sky-400" />
            <h3 className="font-bold text-sm text-slate-100">Discussion Thread</h3>
            <span className="text-xs text-slate-500 font-mono">({totalCommentCount})</span>
          </div>
          <button
            onClick={onClose}
            aria-label="Close comment thread"
            className="p-1 text-slate-400 hover:text-slate-100 rounded-lg hover:bg-slate-800 transition-colors"
          >
            <X size={18} />
          </button>
        </div>

        {/* Post Snippet */}
        <div className="px-4 py-2.5 bg-slate-900/60 border-b border-slate-800 text-xs text-slate-300 flex items-start gap-2.5">
          <img src={post.author.avatar} alt="" className="w-5 h-5 rounded-full object-cover shrink-0 mt-0.5" />
          <div className="line-clamp-2 text-slate-400">
            <span className="font-semibold text-slate-200">@{post.author.username}: </span>
            {post.content}
          </div>
        </div>

        {/* Comments Feed */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4 min-h-[220px]">
          {post.comments.length === 0 ? (
            <div className="text-center py-12 text-slate-500 text-xs flex flex-col items-center gap-2">
              <MessageSquare size={24} className="text-slate-700" />
              <span>No comments yet. Start the conversation!</span>
            </div>
          ) : (
            post.comments.map((comment) => renderCommentNode(comment))
          )}
        </div>

        {/* Active Reply Banner */}
        {replyTarget && (
          <div className="px-4 py-1.5 bg-slate-800/80 border-t border-slate-700 flex items-center justify-between text-xs text-sky-400">
            <span>Replying directly to @{replyTarget.author.username}</span>
            <button
              onClick={() => setReplyTarget(null)}
              className="text-slate-400 hover:text-slate-200 p-0.5"
            >
              <X size={14} />
            </button>
          </div>
        )}

        {/* Input Bar */}
        <form onSubmit={handleSubmit} className="p-3 border-t border-slate-800 bg-[#0c0e14] flex items-center gap-2">
          <img
            src={currentUser.avatar}
            alt=""
            className="w-7 h-7 rounded-full object-cover shrink-0 ring-1 ring-slate-800"
          />
          <input
            type="text"
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            placeholder={
              replyTarget
                ? `Replying to @${replyTarget.author.username}...`
                : post.author.id === currentUser.id
                ? 'Reply as post author...'
                : 'Add a thoughtful reply...'
            }
            className="flex-1 bg-slate-900 border border-slate-800 text-xs text-slate-100 rounded-full px-3.5 py-2 focus:outline-none focus:border-sky-500 placeholder-slate-500"
          />
          <button
            type="submit"
            disabled={!inputText.trim()}
            aria-label="Send reply"
            className="p-2 rounded-full bg-sky-500 text-slate-950 font-bold hover:bg-sky-400 disabled:opacity-40 disabled:hover:bg-sky-500 transition-colors shrink-0"
          >
            <Send size={14} />
          </button>
        </form>
      </div>
    </div>
  );
};
