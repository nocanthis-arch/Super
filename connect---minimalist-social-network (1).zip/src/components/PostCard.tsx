import React, { useState, useRef } from 'react';
import { Post, User } from '../types';
import { formatPostTimestamp, getVerificationTick } from '../utils/connectLogic';
import { VerificationTick } from './VerificationTick';
import { SuperLikeAnimation } from './SuperLikeAnimation';
import {
  Heart,
  MessageCircle,
  Share2,
  Eye,
  MoreHorizontal,
  Edit3,
  Trash2,
  Copy,
  Check,
} from 'lucide-react';

interface Props {
  post: Post;
  currentUser: User;
  onLikeToggle: (postId: string) => void;
  onSuperLike: (postId: string) => void;
  onOpenComments: (post: Post) => void;
  onEditPost: (post: Post) => void;
  onDeletePost: (postId: string) => void;
  onSharePost: (postId: string) => void;
}

export const PostCard: React.FC<Props> = ({
  post,
  currentUser,
  onLikeToggle,
  onSuperLike,
  onOpenComments,
  onEditPost,
  onDeletePost,
  onSharePost,
}) => {
  const [showSuperLikeAnim, setShowSuperLikeAnim] = useState(false);
  const [showMenu, setShowMenu] = useState(false);
  const lastTapRef = useRef<number>(0);
  const clickTimeoutRef = useRef<NodeJS.Timeout | null>(null);

  const isAuthor = post.author.id === currentUser.id;
  const formattedTime = formatPostTimestamp(post.createdAt);
  const authorVerification = getVerificationTick(post.author.stats);

  const handleHeartClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    const now = Date.now();
    const DOUBLE_TAP_THRESHOLD = 300;

    if (now - lastTapRef.current < DOUBLE_TAP_THRESHOLD) {
      // Double Tap detected -> Super Like!
      if (clickTimeoutRef.current) {
        clearTimeout(clickTimeoutRef.current);
        clickTimeoutRef.current = null;
      }
      setShowSuperLikeAnim(true);
      onSuperLike(post.id);
    } else {
      // Single Tap candidate
      lastTapRef.current = now;
      clickTimeoutRef.current = setTimeout(() => {
        onLikeToggle(post.id);
        clickTimeoutRef.current = null;
      }, DOUBLE_TAP_THRESHOLD);
    }
  };

  const totalCommentCount = post.comments.reduce(
    (acc, curr) => acc + 1 + (curr.replies ? curr.replies.length : 0),
    0
  );

  return (
    <article className="border-b border-slate-800/80 bg-[#10121a] hover:bg-[#121520] transition-colors p-4 relative">
      {/* Post Header */}
      <div className="flex items-start justify-between gap-3">
        <div className="flex items-start gap-2.5 min-w-0">
          <img
            src={post.author.avatar}
            alt={post.author.name}
            className="w-10 h-10 rounded-full object-cover shrink-0 ring-1 ring-slate-800"
          />
          <div className="min-w-0 flex-1">
            <div className="flex items-center gap-1.5 flex-wrap">
              <span className="font-bold text-sm text-slate-100 truncate">{post.author.name}</span>
              <VerificationTick type={authorVerification} size="sm" />
              <span className="text-[10px] font-semibold tracking-wide uppercase px-1.5 py-0.5 rounded bg-slate-800/80 text-sky-400 border border-slate-700/60">
                {post.author.creativeField}
              </span>
            </div>
            <div className="flex items-center gap-1 text-xs text-slate-500">
              <span className="truncate">@{post.author.username}</span>
              <span>·</span>
              <span className="shrink-0 font-medium text-slate-400">{formattedTime}</span>
            </div>
          </div>
        </div>

        {/* Three dots menu */}
        <div className="relative">
          <button
            onClick={() => setShowMenu(!showMenu)}
            aria-label="Post actions"
            className="p-1 text-slate-400 hover:text-slate-200 rounded-lg hover:bg-slate-800/60 transition-colors"
          >
            <MoreHorizontal size={18} />
          </button>

          {showMenu && (
            <div
              className="absolute right-0 top-full mt-1 w-44 bg-[#141824] border border-slate-700 rounded-xl shadow-2xl py-1.5 z-30 animate-in fade-in zoom-in-95 duration-150"
              onMouseLeave={() => setShowMenu(false)}
            >
              {isAuthor && (
                <>
                  <button
                    onClick={() => {
                      setShowMenu(false);
                      onEditPost(post);
                    }}
                    className="w-full px-3 py-2 text-left text-xs text-slate-200 hover:bg-slate-800 flex items-center gap-2 transition-colors"
                  >
                    <Edit3 size={14} className="text-sky-400" />
                    <span>{post.image ? 'Edit Caption' : 'Edit Content'}</span>
                  </button>
                  <button
                    onClick={() => {
                      setShowMenu(false);
                      onDeletePost(post.id);
                    }}
                    className="w-full px-3 py-2 text-left text-xs text-red-400 hover:bg-red-500/10 flex items-center gap-2 transition-colors"
                  >
                    <Trash2 size={14} />
                    <span>Delete Permanently</span>
                  </button>
                  <div className="my-1 border-t border-slate-800" />
                </>
              )}
              <button
                onClick={() => {
                  setShowMenu(false);
                  onSharePost(post.id);
                }}
                className="w-full px-3 py-2 text-left text-xs text-slate-300 hover:bg-slate-800 flex items-center gap-2 transition-colors"
              >
                <Copy size={14} className="text-slate-400" />
                <span>Copy Post Link</span>
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Post Content */}
      <div className="mt-3 text-slate-200 text-sm leading-relaxed whitespace-pre-wrap break-words">
        {post.content}
      </div>

      {/* Optional Post Photo */}
      {post.image && (
        <div className="mt-3 rounded-xl overflow-hidden border border-slate-800 max-h-96 bg-black">
          <img
            src={post.image}
            alt="Post media"
            className="w-full h-full object-cover max-h-96 hover:opacity-95 transition-opacity"
            loading="lazy"
          />
        </div>
      )}

      {/* Interaction Bar */}
      <div className="mt-4 pt-2 border-t border-slate-800/60 flex items-center justify-between text-xs text-slate-400">
        {/* Like Button with Single Tap (Blue) & Double Tap (Red Super Like) */}
        <div className="relative">
          {showSuperLikeAnim && (
            <SuperLikeAnimation onComplete={() => setShowSuperLikeAnim(false)} />
          )}
          <button
            onClick={handleHeartClick}
            aria-label={
              post.userLikeState === 'red'
                ? 'Super liked (Red)'
                : post.userLikeState === 'blue'
                ? 'Liked (Blue)'
                : 'Like or double tap to Super Like'
            }
            className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-full transition-all group ${
              post.userLikeState === 'red'
                ? 'text-red-500 bg-red-500/10 hover:bg-red-500/20'
                : post.userLikeState === 'blue'
                ? 'text-sky-400 bg-sky-500/10 hover:bg-sky-500/20'
                : 'hover:text-slate-200 hover:bg-slate-800/50'
            }`}
          >
            <Heart
              size={17}
              fill={
                post.userLikeState === 'red'
                  ? '#ef4444'
                  : post.userLikeState === 'blue'
                  ? '#38bdf8'
                  : 'none'
              }
              className={`transition-transform duration-200 group-hover:scale-110 ${
                post.userLikeState === 'red' ? 'text-red-500' : ''
              }`}
            />
            <span
              className={`font-medium ${
                post.userLikeState === 'red'
                  ? 'text-red-400 font-bold'
                  : post.userLikeState === 'blue'
                  ? 'text-sky-400 font-semibold'
                  : ''
              }`}
            >
              {post.likesCount}
            </span>
            {post.superLikesCount > 0 && (
              <span className="text-[10px] text-red-400/80 font-mono">
                ({post.superLikesCount}⚡️)
              </span>
            )}
          </button>
        </div>

        {/* Comment Button */}
        <button
          onClick={() => onOpenComments(post)}
          aria-label="Open threaded comments"
          className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-full hover:text-slate-200 hover:bg-slate-800/50 transition-colors"
        >
          <MessageCircle size={17} />
          <span className="font-medium">{totalCommentCount}</span>
        </button>

        {/* Share Button */}
        <button
          onClick={() => onSharePost(post.id)}
          aria-label="Share post link"
          className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-full hover:text-slate-200 hover:bg-slate-800/50 transition-colors"
        >
          <Share2 size={17} />
          <span className="font-medium">{post.sharesCount}</span>
        </button>

        {/* View Counter */}
        <div className="flex items-center gap-1.5 px-2.5 py-1.5 text-slate-500 font-mono text-[11px]">
          <Eye size={15} className="text-slate-600" />
          <span>{post.viewsCount.toLocaleString()}</span>
        </div>
      </div>
    </article>
  );
};
