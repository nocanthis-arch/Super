import React from 'react';
import { VerificationType } from '../types';
import { Check, Star } from 'lucide-react';

interface Props {
  type: VerificationType;
  size?: 'sm' | 'md' | 'lg';
  showTooltip?: boolean;
}

export const VerificationTick: React.FC<Props> = ({ type, size = 'sm', showTooltip = true }) => {
  if (type === 'none') return null;

  const sizeClasses = {
    sm: 'w-3.5 h-3.5 text-[8px]',
    md: 'w-4 h-4 text-[10px]',
    lg: 'w-5 h-5 text-xs',
  };

  const iconSizes = {
    sm: 9,
    md: 11,
    lg: 13,
  };

  const config = {
    blue: {
      bg: 'bg-sky-500',
      label: 'Blue Tick · 100+ Active Hours',
      icon: <Check size={iconSizes[size]} strokeWidth={3.5} className="text-white" />,
    },
    yellow: {
      bg: 'bg-amber-400',
      label: 'Yellow Tick · 50+ Community Connections',
      icon: <Check size={iconSizes[size]} strokeWidth={3.5} className="text-black" />,
    },
    red: {
      bg: 'bg-red-500',
      label: 'Red Tick (Top Level) · Elite Creator Vanguard',
      icon: <Star size={iconSizes[size]} strokeWidth={0} fill="white" className="text-white" />,
    },
  }[type];

  return (
    <span
      className="relative group inline-flex items-center ml-1 align-middle select-none"
      title={showTooltip ? config.label : undefined}
    >
      <span
        className={`inline-flex items-center justify-center rounded-full shadow-sm ${config.bg} ${sizeClasses[size]}`}
      >
        {config.icon}
      </span>
      {showTooltip && (
        <span className="pointer-events-none absolute bottom-full left-1/2 -translate-x-1/2 mb-1.5 hidden group-hover:block z-30 px-2 py-1 text-[11px] font-medium text-slate-100 bg-slate-900 border border-slate-700 rounded-md whitespace-nowrap shadow-xl">
          {config.label}
        </span>
      )}
    </span>
  );
};
