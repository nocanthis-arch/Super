import React, { useEffect, useState } from 'react';
import { Heart } from 'lucide-react';

interface Props {
  onComplete: () => void;
}

export const SuperLikeAnimation: React.FC<Props> = ({ onComplete }) => {
  const [particles] = useState(() =>
    Array.from({ length: 12 }, (_, i) => {
      const angle = (i * 30 * Math.PI) / 180;
      const distance = 26 + Math.random() * 16;
      return {
        id: i,
        x: Math.cos(angle) * distance,
        y: Math.sin(angle) * distance,
        scale: 0.6 + Math.random() * 0.7,
        delay: Math.random() * 60,
      };
    })
  );

  useEffect(() => {
    const timer = setTimeout(() => {
      onComplete();
    }, 850);
    return () => clearTimeout(timer);
  }, [onComplete]);

  return (
    <div className="absolute inset-0 pointer-events-none flex items-center justify-center z-20">
      {/* Expanding Ring */}
      <div className="absolute w-10 h-10 rounded-full border-2 border-red-500 animate-ping opacity-60" />

      {/* Bursting particles */}
      {particles.map((p) => (
        <span
          key={p.id}
          className="absolute w-1.5 h-1.5 rounded-full bg-red-500 shadow-[0_0_8px_rgba(239,68,68,0.8)] transition-all duration-700 ease-out"
          style={{
            transform: `translate(${p.x}px, ${p.y}px) scale(${p.scale})`,
            animation: 'fadeParticle 0.75s ease-out forwards',
          }}
        />
      ))}

      {/* Main Burst Heart */}
      <div className="animate-bounce scale-125 transition-transform duration-300">
        <Heart
          size={28}
          fill="#ef4444"
          className="text-red-500 drop-shadow-[0_0_12px_rgba(239,68,68,0.9)]"
        />
      </div>

      <style>{`
        @keyframes fadeParticle {
          0% {
            opacity: 1;
            transform: translate(0, 0) scale(1);
          }
          100% {
            opacity: 0;
            transform: translate(var(--x, 20px), var(--y, 20px)) scale(0.2);
          }
        }
      `}</style>
    </div>
  );
};
