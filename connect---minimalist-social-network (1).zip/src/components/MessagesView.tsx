import React, { useState } from 'react';
import { Conversation, User } from '../types';
import { getVerificationTick } from '../utils/connectLogic';
import { VerificationTick } from './VerificationTick';
import { Send, ArrowLeft, CheckCheck, Edit } from 'lucide-react';

interface Props {
  conversations: Conversation[];
  currentUser: User;
  onSendMessage: (conversationId: string, text: string) => void;
}

export const MessagesView: React.FC<Props> = ({
  conversations,
  currentUser,
  onSendMessage,
}) => {
  const [selectedConvId, setSelectedConvId] = useState<string | null>(null);
  const [inputText, setInputText] = useState('');

  const activeConversation = conversations.find((c) => c.id === selectedConvId);

  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim() || !selectedConvId) return;

    onSendMessage(selectedConvId, inputText.trim());
    setInputText('');
  };

  if (activeConversation) {
    const creatorTick = getVerificationTick(activeConversation.user.stats);

    return (
      <div className="flex flex-col h-[calc(100vh-130px)] sm:h-[620px] bg-[#090a0f] text-slate-100">
        {/* Chat Header */}
        <div className="px-4 py-3 border-b border-slate-800 flex items-center justify-between bg-[#0e111a]">
          <div className="flex items-center gap-3">
            <button
              onClick={() => setSelectedConvId(null)}
              aria-label="Back to conversations"
              className="p-1 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors"
            >
              <ArrowLeft size={18} />
            </button>
            <div className="flex items-center gap-2">
              <img
                src={activeConversation.user.avatar}
                alt=""
                className="w-8 h-8 rounded-full object-cover ring-1 ring-slate-700"
              />
              <div>
                <div className="flex items-center gap-1">
                  <span className="font-bold text-xs text-white">
                    {activeConversation.user.name}
                  </span>
                  <VerificationTick type={creatorTick} size="sm" />
                </div>
                <span className="text-[10px] text-slate-400">
                  @{activeConversation.user.username} · {activeConversation.user.creativeField}
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Message Bubble Feed */}
        <div className="flex-1 overflow-y-auto p-4 space-y-3">
          {activeConversation.messages.map((m) => {
            const isMe = m.senderId === currentUser.id;
            return (
              <div
                key={m.id}
                className={`flex flex-col ${isMe ? 'items-end' : 'items-start'}`}
              >
                <div
                  className={`max-w-[78%] px-3.5 py-2 rounded-2xl text-xs leading-relaxed ${
                    isMe
                      ? 'bg-sky-500 text-slate-950 font-medium rounded-br-xs'
                      : 'bg-slate-850 text-slate-200 border border-slate-800 rounded-bl-xs'
                  }`}
                >
                  {m.text}
                </div>
                <span className="text-[10px] text-slate-500 mt-1 px-1 flex items-center gap-1 font-mono">
                  {m.timestamp}
                  {isMe && <CheckCheck size={11} className="text-sky-400" />}
                </span>
              </div>
            );
          })}
        </div>

        {/* Chat Input Bar */}
        <form
          onSubmit={handleSend}
          className="p-3 border-t border-slate-800 bg-[#0c0e15] flex items-center gap-2"
        >
          <input
            type="text"
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            placeholder={`Message ${activeConversation.user.name.split(' ')[0]}...`}
            className="flex-1 bg-slate-900 border border-slate-800 text-xs text-slate-100 rounded-full px-4 py-2.5 focus:outline-none focus:border-sky-500 placeholder-slate-500"
            autoFocus
          />
          <button
            type="submit"
            disabled={!inputText.trim()}
            aria-label="Send message"
            className="p-2.5 rounded-full bg-sky-500 text-slate-950 font-bold hover:bg-sky-400 disabled:opacity-40 transition-colors shrink-0"
          >
            <Send size={15} />
          </button>
        </form>
      </div>
    );
  }

  return (
    <div className="bg-[#090a0f] text-slate-100 min-h-[500px]">
      <div className="px-4 py-3 border-b border-slate-800/80 flex items-center justify-between sticky top-0 bg-[#090a0f]/90 backdrop-blur-md z-10">
        <h2 className="font-bold text-base text-slate-100">Messages</h2>
        <button
          onClick={() => {
            if (conversations.length > 0) setSelectedConvId(conversations[0].id);
          }}
          className="text-xs text-sky-400 font-semibold flex items-center gap-1 hover:underline"
        >
          <Edit size={14} />
          <span>New</span>
        </button>
      </div>

      <div className="divide-y divide-slate-800/60">
        {conversations.map((conv) => {
          const tick = getVerificationTick(conv.user.stats);
          return (
            <button
              key={conv.id}
              onClick={() => setSelectedConvId(conv.id)}
              className="w-full p-4 flex items-center gap-3.5 hover:bg-slate-900/60 transition-colors text-left focus:outline-none"
            >
              <div className="relative shrink-0">
                <img
                  src={conv.user.avatar}
                  alt={conv.user.name}
                  className="w-12 h-12 rounded-full object-cover ring-1 ring-slate-800"
                />
                <span className="absolute bottom-0 right-0 w-3 h-3 bg-emerald-500 rounded-full ring-2 ring-[#090a0f]" />
              </div>

              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1 truncate">
                    <span className="font-bold text-xs text-white truncate">{conv.user.name}</span>
                    <VerificationTick type={tick} size="sm" />
                  </div>
                  <span className="text-[10px] text-slate-500 font-mono shrink-0">{conv.lastTime}</span>
                </div>

                <p className="text-xs text-slate-400 truncate mt-1">{conv.lastMessage}</p>
              </div>

              {conv.unreadCount > 0 && (
                <span className="w-5 h-5 rounded-full bg-sky-500 text-slate-950 font-bold text-[10px] flex items-center justify-center shrink-0">
                  {conv.unreadCount}
                </span>
              )}
            </button>
          );
        })}
      </div>
    </div>
  );
};
