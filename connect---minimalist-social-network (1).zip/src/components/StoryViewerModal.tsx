import React, { useEffect, useState } from 'react';
import { Story } from '../types';
import { formatPostTimestamp } from '../utils/connectLogic';
import { X, ChevronLeft, ChevronRight } from 'lucide-react';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  stories: Story[];
  initialIndex: number;
}

export const StoryViewerModal: React.FC<Props> = ({
  isOpen,
  onClose,
  stories,
  initialIndex,
}) => {
  const [currentIndex, setCurrentIndex] = useState(initialIndex);
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    setCurrentIndex(initialIndex);
    setProgress(0);
  }, [initialIndex, isOpen]);

  useEffect(() => {
    if (!isOpen) return;

    const interval = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          if (currentIndex < stories.length - 1) {
            setCurrentIndex((curr) => curr + 1);
            return 0;
          } else {
            onClose();
            return 100;
          }
        }
        return prev + 2;
      });
    }, 100);

    return () => clearInterval(interval);
  }, [isOpen, currentIndex, stories.length, onClose]);

  if (!isOpen || stories.length === 0) return null;

  const currentStory = stories[currentIndex];

  const handleNext = () => {
    if (currentIndex < stories.length - 1) {
      setCurrentIndex(currentIndex + 1);
      setProgress(0);
    } else {
      onClose();
    }
  };

  const handlePrev = () => {
    if (currentIndex > 0) {
      setCurrentIndex(currentIndex - 1);
      setProgress(0);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/95">
      <div className="relative w-full max-w-sm h-full max-h-[88vh] rounded-2xl overflow-hidden bg-slate-950 flex flex-col justify-between shadow-2xl border border-slate-800">
        {/* Progress bars */}
        <div className="absolute top-0 inset-x-0 p-3 z-30 flex gap-1.5">
          {stories.map((s, idx) => (
            <div key={s.id} className="h-1 flex-1 bg-white/20 rounded-full overflow-hidden">
              <div
                className="h-full bg-white transition-all duration-100 ease-linear rounded-full"
                style={{
                  width:
                    idx < currentIndex
                      ? '100%'
                      : idx === currentIndex
                      ? `${progress}%`
                      : '0%',
                }}
              />
            </div>
          ))}
        </div>

        {/* Story Header */}
        <div className="absolute top-5 inset-x-0 p-4 z-30 flex items-center justify-between text-white drop-shadow-md">
          <div className="flex items-center gap-2">
            <img
              src={currentStory.user.avatar}
              alt=""
              className="w-8 h-8 rounded-full object-cover ring-2 ring-white/60"
            />
            <div>
              <span className="text-xs font-bold block">{currentStory.user.name}</span>
              <span className="text-[10px] text-white/80">
                {formatPostTimestamp(currentStory.createdAt)}
              </span>
            </div>
          </div>
          <button
            onClick={onClose}
            aria-label="Close story"
            className="p-1 rounded-full bg-black/40 hover:bg-black/70 transition-colors"
          >
            <X size={18} />
          </button>
        </div>

        {/* Story Background / Media */}
        <div className="relative flex-1 flex items-center justify-center overflow-hidden">
          <img
            src={currentStory.mediaUrl}
            alt="Story content"
            className="w-full h-full object-cover"
          />

          {/* Navigation tap targets */}
          <button
            onClick={handlePrev}
            aria-label="Previous story"
            className="absolute left-0 inset-y-0 w-1/3 opacity-0 hover:opacity-100 flex items-center pl-3 text-white transition-opacity"
          >
            <ChevronLeft size={28} className="bg-black/40 p-1 rounded-full" />
          </button>
          <button
            onClick={handleNext}
            aria-label="Next story"
            className="absolute right-0 inset-y-0 w-1/3 opacity-0 hover:opacity-100 flex items-center justify-end pr-3 text-white transition-opacity"
          >
            <ChevronRight size={28} className="bg-black/40 p-1 rounded-full" />
          </button>
        </div>

        {/* Story Caption */}
        {currentStory.caption && (
          <div className="absolute bottom-0 inset-x-0 p-4 bg-gradient-to-t from-black/90 via-black/50 to-transparent text-white text-xs z-30 leading-relaxed">
            <p className="font-medium drop-shadow">{currentStory.caption}</p>
          </div>
        )}
      </div>
    </div>
  );
};
