import React from 'react';
import { X, ShieldCheck, HeartHandshake } from 'lucide-react';

interface InfoModalProps {
  isOpen: boolean;
  onClose: () => void;
  title: string;
  type: 'privacy' | 'about';
}

export const InfoModals: React.FC<InfoModalProps> = ({
  isOpen,
  onClose,
  title,
  type,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-xs">
      <div
        className="w-full max-w-md bg-[#11131b] border border-slate-800 rounded-2xl p-5 shadow-2xl max-h-[85vh] flex flex-col"
        role="dialog"
        aria-modal="true"
      >
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div className="flex items-center gap-2">
            {type === 'privacy' ? (
              <ShieldCheck size={18} className="text-sky-400" />
            ) : (
              <HeartHandshake size={18} className="text-amber-400" />
            )}
            <h3 className="font-bold text-sm text-slate-100">{title}</h3>
          </div>
          <button
            onClick={onClose}
            aria-label="Close dialog"
            className="p-1 text-slate-400 hover:text-slate-100 rounded-lg hover:bg-slate-800 transition-colors"
          >
            <X size={18} />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto py-4 text-xs text-slate-300 space-y-3 leading-relaxed">
          {type === 'privacy' ? (
            <>
              <p>
                <strong>Privacy Policy for Connect:</strong> Connect is designed from first principles with data minimization. We do not sell user biometric data or track off-platform behaviors.
              </p>
              <p>
                <strong>Verification Milestones:</strong> Time spent scrolling (active app usage) is computed locally and synchronized anonymously to award the Blue Verification Tick once 100 hours are reached.
              </p>
              <p>
                <strong>Content Retention:</strong> Users retain 100% ownership of posted texts, images, and creative tags. Permanent post deletion permanently purges media records.
              </p>
            </>
          ) : (
            <>
              <p>
                <strong>About Connect:</strong> Connect is a high-performance minimalist social network built to foster mutual resonance among builders, designers, writers, and generalists.
              </p>
              <p>
                <strong>Core Philosophy:</strong> Replacing passive follower counts with bidirectional connections. Replacing mindless double-taps with deliberate Blue Likes and red Super Likes.
              </p>
              <p>
                <strong>Engineering:</strong> Built with strict 60fps budgets, negligible memory footprint, and low-latency rendering for low-spec hardware worldwide.
              </p>
            </>
          )}
        </div>

        <button
          onClick={onClose}
          className="mt-2 w-full py-2 bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-white rounded-xl transition-colors"
        >
          Close
        </button>
      </div>
    </div>
  );
};
