import React, { useState } from 'react';
import { Post } from '../types';
import { isPostEditable } from '../utils/connectLogic';
import { X, AlertCircle, Trash2, CheckCircle2 } from 'lucide-react';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  post: Post;
  onSave: (postId: string, newContent: string, removeImage?: boolean) => void;
}

export const EditPostModal: React.FC<Props> = ({ isOpen, onClose, post, onSave }) => {
  const [content, setContent] = useState(post.content);
  const [removeImage, setRemoveImage] = useState(false);

  if (!isOpen) return null;

  const editable = isPostEditable(post.createdAt);
  const isImagePost = Boolean(post.image);

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editable) return;
    if (!content.trim()) return;

    onSave(post.id, content.trim(), removeImage);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-xs">
      <div
        className="w-full max-w-md bg-[#11131b] border border-slate-800 rounded-2xl p-5 shadow-2xl relative"
        role="dialog"
        aria-modal="true"
      >
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <h3 className="font-bold text-sm text-slate-100">
            {isImagePost ? 'Edit Caption' : 'Edit Post'}
          </h3>
          <button
            onClick={onClose}
            aria-label="Close edit dialog"
            className="p-1 text-slate-400 hover:text-slate-100 rounded-lg hover:bg-slate-800 transition-colors"
          >
            <X size={18} />
          </button>
        </div>

        {!editable ? (
          <div className="mt-4 p-3 bg-red-500/10 border border-red-500/30 rounded-xl text-red-400 text-xs flex items-start gap-2.5">
            <AlertCircle size={18} className="shrink-0 mt-0.5" />
            <div>
              <p className="font-semibold">Editing Window Expired</p>
              <p className="text-slate-400 mt-1">
                Per Connect integrity rules, posts can only be edited within 1 hour of publication. You can still delete this post if needed.
              </p>
            </div>
          </div>
        ) : (
          <form onSubmit={handleSave} className="mt-4 space-y-4">
            <div className="text-[11px] text-sky-400 flex items-center gap-1.5 bg-sky-500/10 px-2.5 py-1.5 rounded-lg border border-sky-500/20">
              <CheckCircle2 size={13} />
              <span>
                {isImagePost
                  ? 'Image posts: only caption can be modified. You may detach the image below.'
                  : 'Eligible for editing (within 1-hour window).'}
              </span>
            </div>

            <div>
              <label htmlFor="edit-content-input" className="block text-xs font-medium text-slate-400 mb-1.5">
                {isImagePost ? 'Caption Text' : 'Post Content'}
              </label>
              <textarea
                id="edit-content-input"
                rows={4}
                value={content}
                onChange={(e) => setContent(e.target.value)}
                className="w-full bg-slate-900 border border-slate-800 text-xs text-slate-100 rounded-xl p-3 focus:outline-none focus:border-sky-500 resize-none leading-relaxed"
                placeholder="Update your post..."
              />
            </div>

            {post.image && !removeImage && (
              <div className="relative rounded-xl overflow-hidden border border-slate-800 max-h-36">
                <img src={post.image} alt="Post attachment" className="w-full h-full object-cover" />
                <button
                  type="button"
                  onClick={() => setRemoveImage(true)}
                  className="absolute bottom-2 right-2 px-2.5 py-1 bg-red-600/90 hover:bg-red-600 text-white text-[11px] font-semibold rounded-md flex items-center gap-1 shadow-md transition-colors"
                >
                  <Trash2 size={12} />
                  Delete Image
                </button>
              </div>
            )}

            {removeImage && (
              <div className="text-xs text-amber-400 bg-amber-500/10 p-2.5 rounded-lg border border-amber-500/20 flex items-center justify-between">
                <span>Image will be permanently removed upon saving</span>
                <button
                  type="button"
                  onClick={() => setRemoveImage(false)}
                  className="text-[11px] underline text-slate-400 hover:text-white"
                >
                  Undo
                </button>
              </div>
            )}

            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={onClose}
                className="px-3.5 py-1.5 text-xs text-slate-400 hover:text-white font-medium rounded-lg hover:bg-slate-800 transition-colors"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={!content.trim()}
                className="px-4 py-1.5 text-xs font-semibold rounded-lg bg-sky-500 text-slate-950 hover:bg-sky-400 disabled:opacity-50 transition-colors"
              >
                Save Changes
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};
