import React, { useState } from 'react';
import { FLUTTER_FILES, FlutterSourceFile } from '../data/flutterCode';
import { X, Copy, Check, Code, FileCode, Download, Folder } from 'lucide-react';

interface Props {
  isOpen: boolean;
  onClose: () => void;
}

export const FlutterCodeViewerModal: React.FC<Props> = ({ isOpen, onClose }) => {
  const [selectedPath, setSelectedPath] = useState<string>('lib/main.dart');
  const [copiedFile, setCopiedFile] = useState<string | null>(null);
  const [copiedAll, setCopiedAll] = useState(false);

  if (!isOpen) return null;

  const currentFile = FLUTTER_FILES.find((f) => f.path === selectedPath) || FLUTTER_FILES[1];

  const handleCopyFile = (file: FlutterSourceFile) => {
    navigator.clipboard.writeText(file.code);
    setCopiedFile(file.path);
    setTimeout(() => setCopiedFile(null), 2000);
  };

  const handleCopyAll = () => {
    const fullProject = FLUTTER_FILES.map(
      (f) => `// ==========================================\n// FILE: ${f.path}\n// Description: ${f.description}\n// ==========================================\n\n${f.code}\n`
    ).join('\n\n');

    navigator.clipboard.writeText(fullProject);
    setCopiedAll(true);
    setTimeout(() => setCopiedAll(false), 2500);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-black/85 backdrop-blur-xs">
      <div
        className="w-full max-w-5xl bg-[#0c0e15] border border-slate-800 rounded-2xl shadow-2xl h-[90vh] flex flex-col overflow-hidden"
        role="dialog"
        aria-modal="true"
      >
        {/* Top Header */}
        <div className="px-5 py-3 border-b border-slate-800 flex items-center justify-between bg-[#11141e]">
          <div className="flex items-center gap-2.5">
            <div className="p-1.5 rounded-lg bg-sky-500/20 text-sky-400">
              <Code size={18} />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-bold text-sm text-white">Flutter & Dart Codebase Hub</h3>
                <span className="text-[10px] font-mono bg-sky-500/10 text-sky-400 px-2 py-0.5 rounded border border-sky-500/20">
                  Dart 3.x · Flutter 3.x
                </span>
              </div>
              <p className="text-[11px] text-slate-400">
                100% complete, production-ready implementation with zero shortcuts.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleCopyAll}
              className="px-3 py-1.5 text-xs font-semibold rounded-lg bg-sky-500 text-slate-950 hover:bg-sky-400 flex items-center gap-1.5 transition-colors shadow-sm"
            >
              {copiedAll ? <Check size={14} /> : <Copy size={14} />}
              <span>{copiedAll ? 'All Files Copied!' : 'Copy Entire Project'}</span>
            </button>

            <button
              onClick={onClose}
              aria-label="Close code explorer"
              className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors"
            >
              <X size={18} />
            </button>
          </div>
        </div>

        {/* Content Body: Sidebar + Code Display */}
        <div className="flex-1 flex flex-col md:flex-row min-h-0 overflow-hidden">
          {/* File Explorer Sidebar */}
          <div className="w-full md:w-64 border-b md:border-b-0 md:border-r border-slate-800 bg-[#0e111a] p-3 overflow-y-auto shrink-0 space-y-1">
            <div className="text-[10px] uppercase font-bold tracking-wider text-slate-500 px-2 py-1 flex items-center gap-1">
              <Folder size={12} />
              <span>Project Files ({FLUTTER_FILES.length})</span>
            </div>

            {FLUTTER_FILES.map((f) => {
              const isSelected = f.path === selectedPath;
              return (
                <button
                  key={f.path}
                  onClick={() => setSelectedPath(f.path)}
                  className={`w-full text-left px-2.5 py-1.5 rounded-lg text-xs font-mono flex items-center justify-between transition-colors ${
                    isSelected
                      ? 'bg-sky-500/20 text-sky-400 font-bold border border-sky-500/30'
                      : 'text-slate-400 hover:bg-slate-800/60 hover:text-slate-200'
                  }`}
                >
                  <span className="truncate">{f.path}</span>
                  {isSelected && <span className="w-1.5 h-1.5 rounded-full bg-sky-400 shrink-0" />}
                </button>
              );
            })}
          </div>

          {/* Code Viewer Panel */}
          <div className="flex-1 flex flex-col bg-[#090a10] min-w-0">
            {/* File info bar */}
            <div className="px-4 py-2 bg-[#121520] border-b border-slate-800 flex items-center justify-between">
              <div className="flex items-center gap-2 truncate">
                <FileCode size={14} className="text-sky-400 shrink-0" />
                <span className="font-mono text-xs font-semibold text-slate-200 truncate">
                  {currentFile.path}
                </span>
                <span className="text-[11px] text-slate-500 hidden sm:inline">
                  — {currentFile.description}
                </span>
              </div>
              <button
                onClick={() => handleCopyFile(currentFile)}
                className="px-2.5 py-1 text-xs text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 rounded-md flex items-center gap-1 transition-colors shrink-0"
              >
                {copiedFile === currentFile.path ? (
                  <>
                    <Check size={13} className="text-emerald-400" />
                    <span className="text-emerald-400">Copied</span>
                  </>
                ) : (
                  <>
                    <Copy size={13} />
                    <span>Copy File</span>
                  </>
                )}
              </button>
            </div>

            {/* Code content pre */}
            <div className="flex-1 overflow-auto p-4 font-mono text-[11px] sm:text-xs text-slate-300 leading-relaxed selection:bg-sky-500/30">
              <pre className="whitespace-pre">
                <code>{currentFile.code}</code>
              </pre>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
