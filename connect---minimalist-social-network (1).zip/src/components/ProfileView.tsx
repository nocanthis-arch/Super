import React, { useState } from 'react';
import { User, CreativeField, Achievement, Post } from '../types';
import { getVerificationTick } from '../utils/connectLogic';
import { VerificationTick } from './VerificationTick';
import {
  MoreVertical,
  Camera,
  Users,
  Clock,
  Eye,
  Award,
  Sparkles,
  Settings,
  BarChart2,
  Shield,
  HelpCircle,
  LogOut,
  Check,
  UserPlus,
  Sliders,
} from 'lucide-react';

interface Props {
  user: User;
  achievements: Achievement[];
  userPosts: Post[];
  onUpdateUser: (updatedUser: User) => void;
  onOpenSettings: () => void;
  onOpenInsights: () => void;
  onOpenAchievementsList: () => void;
  onOpenPrivacy: () => void;
  onOpenAbout: () => void;
  onSignOut: () => void;
}

const CREATIVE_FIELDS: CreativeField[] = [
  'Developer',
  'Designer',
  'Writer',
  'Generalist',
  'Sound Architect',
  'Photographer',
  'Product Lead',
];

const AVATAR_PRESETS = [
  'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=400&auto=format&fit=crop&q=80',
  'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=400&auto=format&fit=crop&q=80',
  'https://images.unsplash.com/photo-1580489944761-15a19d654956?w=400&auto=format&fit=crop&q=80',
  'https://images.unsplash.com/photo-1570295999919-56ceb5ecca61?w=400&auto=format&fit=crop&q=80',
];

export const ProfileView: React.FC<Props> = ({
  user,
  achievements,
  userPosts,
  onUpdateUser,
  onOpenSettings,
  onOpenInsights,
  onOpenAchievementsList,
  onOpenPrivacy,
  onOpenAbout,
  onSignOut,
}) => {
  const [showMenu, setShowMenu] = useState(false);
  const [showEditPhotoModal, setShowEditPhotoModal] = useState(false);
  const [showEditFieldModal, setShowEditFieldModal] = useState(false);
  const [showSimulateStats, setShowSimulateStats] = useState(false);

  const verification = getVerificationTick(user.stats);

  const handleConnectToggle = () => {
    let nextStatus: 'connect' | 'pending' | 'connected' = 'connect';
    let delta = 0;

    if (user.connectionStatus === 'connect') {
      nextStatus = 'pending';
    } else if (user.connectionStatus === 'pending') {
      nextStatus = 'connected';
      delta = 1;
    } else {
      nextStatus = 'connect';
      delta = -1;
    }

    onUpdateUser({
      ...user,
      connectionStatus: nextStatus,
      stats: {
        ...user.stats,
        connectionsCount: Math.max(0, user.stats.connectionsCount + delta),
      },
    });
  };

  const handleFieldChange = (newField: CreativeField) => {
    onUpdateUser({ ...user, creativeField: newField });
    setShowEditFieldModal(false);
  };

  const handleAvatarChange = (newAvatar: string) => {
    onUpdateUser({ ...user, avatar: newAvatar });
    setShowEditPhotoModal(false);
  };

  return (
    <div className="pb-16 bg-[#090a0f] text-slate-100">
      {/* Top Bar with Three-Dot Menu */}
      <div className="flex items-center justify-between px-4 py-3 border-b border-slate-800/80 sticky top-0 bg-[#090a0f]/90 backdrop-blur-md z-20">
        <h2 className="font-bold text-base text-slate-100">Profile</h2>
        <div className="relative">
          <button
            onClick={() => setShowMenu(!showMenu)}
            aria-label="Profile menu"
            className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors"
          >
            <MoreVertical size={20} />
          </button>

          {/* Three-Dot Menu Options */}
          {showMenu && (
            <div
              className="absolute right-0 top-full mt-1 w-56 bg-[#141824] border border-slate-700 rounded-xl shadow-2xl py-2 z-40 animate-in fade-in zoom-in-95 duration-150"
              onMouseLeave={() => setShowMenu(false)}
            >
              <button
                onClick={() => {
                  setShowMenu(false);
                  onOpenSettings();
                }}
                className="w-full px-4 py-2.5 text-left text-xs text-slate-200 hover:bg-slate-800 flex items-center gap-2.5 transition-colors"
              >
                <Settings size={15} className="text-slate-400" />
                <span>Settings</span>
              </button>

              <button
                onClick={() => {
                  setShowMenu(false);
                  onOpenInsights();
                }}
                className="w-full px-4 py-2.5 text-left text-xs text-slate-200 hover:bg-slate-800 flex items-center gap-2.5 transition-colors"
              >
                <BarChart2 size={15} className="text-sky-400" />
                <span>Post Insights & Analytics</span>
              </button>

              <button
                onClick={() => {
                  setShowMenu(false);
                  onOpenAchievementsList();
                }}
                className="w-full px-4 py-2.5 text-left text-xs text-slate-200 hover:bg-slate-800 flex items-center gap-2.5 transition-colors"
              >
                <Award size={15} className="text-amber-400" />
                <span>Achievements & Level Status</span>
              </button>

              <button
                onClick={() => {
                  setShowMenu(false);
                  onOpenPrivacy();
                }}
                className="w-full px-4 py-2.5 text-left text-xs text-slate-200 hover:bg-slate-800 flex items-center gap-2.5 transition-colors"
              >
                <Shield size={15} className="text-slate-400" />
                <span>Privacy Policy</span>
              </button>

              <button
                onClick={() => {
                  setShowMenu(false);
                  onOpenAbout();
                }}
                className="w-full px-4 py-2.5 text-left text-xs text-slate-200 hover:bg-slate-800 flex items-center gap-2.5 transition-colors"
              >
                <HelpCircle size={15} className="text-slate-400" />
                <span>About Us</span>
              </button>

              <div className="my-1 border-t border-slate-800" />

              <button
                onClick={() => {
                  setShowMenu(false);
                  onSignOut();
                }}
                className="w-full px-4 py-2.5 text-left text-xs text-red-400 hover:bg-red-500/10 flex items-center gap-2.5 transition-colors"
              >
                <LogOut size={15} />
                <span>Sign Out / Logout</span>
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Profile Header */}
      <div className="p-4 border-b border-slate-800/80">
        <div className="flex items-start gap-4">
          {/* User Photo with edit/upload option */}
          <div className="relative group shrink-0">
            <img
              src={user.avatar}
              alt={user.name}
              className="w-20 h-20 rounded-full object-cover ring-2 ring-slate-800"
            />
            <button
              onClick={() => setShowEditPhotoModal(true)}
              aria-label="Edit or upload profile photo"
              className="absolute inset-0 bg-black/50 rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity text-white"
            >
              <Camera size={20} />
            </button>
            <button
              onClick={() => setShowEditPhotoModal(true)}
              className="absolute bottom-0 right-0 p-1 bg-sky-500 hover:bg-sky-400 text-slate-950 rounded-full ring-2 ring-[#090a0f] shadow transition-colors"
              title="Change Photo"
            >
              <Camera size={12} />
            </button>
          </div>

          {/* User Info */}
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-1.5 flex-wrap">
              <h1 className="font-extrabold text-base text-white tracking-tight">{user.name}</h1>
              <VerificationTick type={verification} size="md" />
            </div>

            <p className="text-xs text-slate-400">@{user.username}</p>

            {/* Creative Field Tag with change picker */}
            <div className="mt-2 flex items-center gap-2">
              <button
                onClick={() => setShowEditFieldModal(true)}
                className="inline-flex items-center gap-1 px-2.5 py-1 rounded-md text-xs font-semibold bg-slate-850 hover:bg-slate-800 text-sky-400 border border-slate-700/80 transition-colors"
                title="Tap to change creative field tag"
              >
                <span>{user.creativeField}</span>
                <span className="text-[10px] text-slate-500">▾</span>
              </button>
            </div>
          </div>
        </div>

        {/* Bio */}
        <p className="mt-3 text-xs text-slate-300 leading-relaxed">{user.bio}</p>

        {/* Dynamic Verification Badge Status Banner */}
        <div className="mt-4 p-2.5 rounded-xl bg-slate-900/80 border border-slate-800 flex items-center justify-between text-xs">
          <div className="flex items-center gap-2">
            <VerificationTick type={verification} size="sm" showTooltip={false} />
            <span className="text-slate-300 font-medium">
              {verification === 'red' && 'Red Tick Vanguard Active'}
              {verification === 'yellow' && 'Yellow Community Milestone Active'}
              {verification === 'blue' && 'Blue Usage Milestone (100h+) Active'}
              {verification === 'none' && 'Verification In Progress'}
            </span>
          </div>
          <button
            onClick={() => setShowSimulateStats(!showSimulateStats)}
            className="text-[11px] text-sky-400 hover:underline flex items-center gap-1 font-medium"
          >
            <Sliders size={12} />
            <span>{showSimulateStats ? 'Close Sim' : 'Simulate Stats'}</span>
          </button>
        </div>

        {/* Interactive Stats Simulator (Demonstrates Blue, Yellow, Red tick unlock triggers) */}
        {showSimulateStats && (
          <div className="mt-2.5 p-3 rounded-xl bg-slate-950 border border-sky-500/30 text-xs space-y-2.5">
            <span className="font-bold text-sky-400 block text-[11px] uppercase tracking-wider">
              Interactive Verification Simulator
            </span>
            <div className="space-y-1.5">
              <div className="flex justify-between text-slate-400 text-[11px]">
                <span>Active Scrolling/Usage: {user.stats.activeUsageHours}h</span>
                <span className={user.stats.activeUsageHours >= 100 ? 'text-sky-400' : 'text-slate-500'}>
                  (Need 100h for Blue)
                </span>
              </div>
              <input
                type="range"
                min="0"
                max="250"
                value={user.stats.activeUsageHours}
                onChange={(e) =>
                  onUpdateUser({
                    ...user,
                    stats: { ...user.stats, activeUsageHours: Number(e.target.value) },
                  })
                }
                className="w-full accent-sky-400 h-1 bg-slate-800 rounded-lg cursor-pointer"
              />
            </div>

            <div className="space-y-1.5">
              <div className="flex justify-between text-slate-400 text-[11px]">
                <span>Community Connections: {user.stats.connectionsCount}</span>
                <span className={user.stats.connectionsCount >= 50 ? 'text-amber-400' : 'text-slate-500'}>
                  (Need 50 for Yellow)
                </span>
              </div>
              <input
                type="range"
                min="0"
                max="120"
                value={user.stats.connectionsCount}
                onChange={(e) =>
                  onUpdateUser({
                    ...user,
                    stats: { ...user.stats, connectionsCount: Number(e.target.value) },
                  })
                }
                className="w-full accent-amber-400 h-1 bg-slate-800 rounded-lg cursor-pointer"
              />
            </div>

            <div className="flex items-center justify-between pt-1">
              <label className="text-[11px] text-slate-300 flex items-center gap-1.5 cursor-pointer">
                <input
                  type="checkbox"
                  checked={Boolean(user.stats.isTopCreator)}
                  onChange={(e) =>
                    onUpdateUser({
                      ...user,
                      stats: { ...user.stats, isTopCreator: e.target.checked },
                    })
                  }
                  className="rounded text-red-500 accent-red-500"
                />
                <span>Top Creator Status (Red Tick)</span>
              </label>
            </div>
          </div>
        )}

        {/* Metrics Grid */}
        <div className="grid grid-cols-3 gap-2 mt-4 text-center">
          <div className="p-2.5 bg-slate-900/60 rounded-xl border border-slate-800/80">
            <span className="block font-bold text-sm text-slate-100">
              {user.stats.activeUsageHours}h
            </span>
            <span className="text-[10px] text-slate-400 flex items-center justify-center gap-1 mt-0.5">
              <Clock size={11} />
              Active Usage
            </span>
          </div>

          <div className="p-2.5 bg-slate-900/60 rounded-xl border border-slate-800/80">
            <span className="block font-bold text-sm text-slate-100">
              {user.stats.connectionsCount}
            </span>
            <span className="text-[10px] text-slate-400 flex items-center justify-center gap-1 mt-0.5">
              <Users size={11} />
              Connections
            </span>
          </div>

          <div className="p-2.5 bg-slate-900/60 rounded-xl border border-slate-800/80">
            <span className="block font-bold text-sm text-slate-100">
              {user.stats.totalPostViews.toLocaleString()}
            </span>
            <span className="text-[10px] text-slate-400 flex items-center justify-center gap-1 mt-0.5">
              <Eye size={11} />
              Post Views
            </span>
          </div>
        </div>

        {/* "Connect" Button (Mutual Connection system) */}
        <div className="mt-4">
          <button
            onClick={handleConnectToggle}
            className={`w-full py-2.5 rounded-xl font-bold text-xs flex items-center justify-center gap-2 transition-all ${
              user.connectionStatus === 'connected'
                ? 'bg-slate-800 text-slate-200 hover:bg-slate-700/80 border border-slate-700'
                : user.connectionStatus === 'pending'
                ? 'bg-sky-500/20 text-sky-400 border border-sky-500/40'
                : 'bg-sky-500 text-slate-950 hover:bg-sky-400'
            }`}
          >
            {user.connectionStatus === 'connected' && (
              <>
                <Check size={15} />
                <span>Connected</span>
              </>
            )}
            {user.connectionStatus === 'pending' && (
              <>
                <Clock size={15} className="animate-spin" />
                <span>Connection Request Pending...</span>
              </>
            )}
            {user.connectionStatus === 'connect' && (
              <>
                <UserPlus size={15} />
                <span>Connect</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* Achievements Section: Dedicated Scrollable Section */}
      <div className="p-4 border-b border-slate-800/80">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <Award size={16} className="text-amber-400" />
            <h3 className="font-bold text-sm text-slate-100">Achievements & Milestones</h3>
          </div>
          <button
            onClick={onOpenAchievementsList}
            className="text-xs text-sky-400 hover:underline font-medium"
          >
            View All ({achievements.filter((a) => a.isUnlocked).length}/{achievements.length})
          </button>
        </div>

        {/* Horizontal scrollable milestone cards */}
        <div className="flex gap-3 overflow-x-auto no-scrollbar pb-2">
          {achievements.map((ach) => {
            const percent = Math.min(100, Math.round((ach.currentProgress / ach.targetProgress) * 100));
            return (
              <div
                key={ach.id}
                className={`w-52 shrink-0 p-3 rounded-xl border transition-all ${
                  ach.isUnlocked
                    ? 'bg-slate-900/90 border-sky-500/30'
                    : 'bg-slate-950/80 border-slate-800/80 opacity-75'
                }`}
              >
                <div className="flex items-center justify-between mb-2">
                  <div
                    className={`p-1.5 rounded-lg ${
                      ach.isUnlocked ? 'bg-sky-500/20 text-sky-400' : 'bg-slate-800 text-slate-500'
                    }`}
                  >
                    <Sparkles size={14} />
                  </div>
                  {ach.isUnlocked ? (
                    <span className="text-[9px] font-bold uppercase tracking-wider text-sky-400 bg-sky-500/10 px-1.5 py-0.5 rounded">
                      Earned
                    </span>
                  ) : (
                    <span className="text-[10px] text-slate-500 font-mono">{percent}%</span>
                  )}
                </div>

                <h4 className="font-semibold text-xs text-slate-100 truncate">{ach.title}</h4>
                <p className="text-[11px] text-slate-400 mt-0.5 line-clamp-2 leading-tight">
                  {ach.description}
                </p>

                <div className="mt-2.5">
                  <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
                    <div
                      className={`h-full rounded-full transition-all duration-500 ${
                        ach.isUnlocked ? 'bg-sky-500' : 'bg-slate-600'
                      }`}
                      style={{ width: `${percent}%` }}
                    />
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* User's Created Posts Header */}
      <div className="p-4">
        <div className="flex items-center justify-between mb-3">
          <h3 className="font-bold text-sm text-slate-200">Your Posts ({userPosts.length})</h3>
          <span className="text-xs text-slate-500">Tap three dots on posts to edit (1h window) or delete</span>
        </div>
      </div>

      {/* Edit Creative Field Tag Modal */}
      {showEditFieldModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-xs">
          <div className="w-full max-w-xs bg-[#11131b] border border-slate-800 rounded-2xl p-4 shadow-2xl">
            <h3 className="font-bold text-sm text-slate-100 mb-3">Select Creative Field Tag</h3>
            <div className="space-y-1.5">
              {CREATIVE_FIELDS.map((f) => (
                <button
                  key={f}
                  onClick={() => handleFieldChange(f)}
                  className={`w-full px-3 py-2 text-left text-xs rounded-xl flex items-center justify-between transition-colors ${
                    user.creativeField === f
                      ? 'bg-sky-500/20 text-sky-400 font-bold border border-sky-500/30'
                      : 'text-slate-300 hover:bg-slate-800'
                  }`}
                >
                  <span>{f}</span>
                  {user.creativeField === f && <Check size={14} />}
                </button>
              ))}
            </div>
            <button
              onClick={() => setShowEditFieldModal(false)}
              className="mt-3 w-full py-1.5 text-xs text-slate-400 hover:text-white"
            >
              Cancel
            </button>
          </div>
        </div>
      )}

      {/* Edit Profile Photo Modal */}
      {showEditPhotoModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-xs">
          <div className="w-full max-w-sm bg-[#11131b] border border-slate-800 rounded-2xl p-4 shadow-2xl">
            <h3 className="font-bold text-sm text-slate-100 mb-3">Choose Profile Photo</h3>
            <div className="grid grid-cols-2 gap-3 mb-4">
              {AVATAR_PRESETS.map((preset, idx) => (
                <button
                  key={idx}
                  onClick={() => handleAvatarChange(preset)}
                  className="rounded-xl overflow-hidden border-2 border-slate-800 hover:border-sky-500 transition-colors h-24"
                >
                  <img src={preset} alt="preset" className="w-full h-full object-cover" />
                </button>
              ))}
            </div>
            <button
              onClick={() => setShowEditPhotoModal(false)}
              className="w-full py-1.5 text-xs text-slate-400 hover:text-white"
            >
              Cancel
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
