import React from 'react';
import { Achievement } from '../types';
import { X, Award, CheckCircle2, Lock } from 'lucide-react';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  achievements: Achievement[];
}

export const AchievementsModal: React.FC<Props> = ({
  isOpen,
  onClose,
  achievements,
}) => {
  if (!isOpen) return null;

  const unlockedCount = achievements.filter((a) => a.isUnlocked).length;
  const level = unlockedCount >= 3 ? 'Elite Vanguard (Level 3)' : unlockedCount >= 2 ? 'Community Leader (Level 2)' : 'Contributor (Level 1)';

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-xs">
      <div
        className="w-full max-w-md bg-[#11131b] border border-slate-800 rounded-2xl p-5 shadow-2xl max-h-[88vh] flex flex-col"
        role="dialog"
        aria-modal="true"
      >
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <Award size={18} className="text-amber-400" />
            <h3 className="font-bold text-sm text-slate-100">Milestones & Level Status</h3>
          </div>
          <button
            onClick={onClose}
            aria-label="Close achievements"
            className="p-1 text-slate-400 hover:text-slate-100 rounded-lg hover:bg-slate-800 transition-colors"
          >
            <X size={18} />
          </button>
        </div>

        {/* Level Banner */}
        <div className="my-4 p-3.5 bg-gradient-to-r from-amber-500/15 via-sky-500/15 to-transparent rounded-xl border border-amber-500/30 flex items-center justify-between">
          <div>
            <span className="text-[10px] uppercase font-bold text-amber-400 tracking-wider block">
              Current Creator Tier
            </span>
            <span className="text-sm font-extrabold text-white mt-0.5 block">{level}</span>
          </div>
          <div className="text-right">
            <span className="text-xs font-bold text-sky-400 font-mono">
              {unlockedCount} / {achievements.length}
            </span>
            <span className="text-[10px] text-slate-400 block">Badges Earned</span>
          </div>
        </div>

        {/* Achievements list */}
        <div className="flex-1 overflow-y-auto space-y-3 pr-1">
          {achievements.map((ach) => {
            const percent = Math.min(100, Math.round((ach.currentProgress / ach.targetProgress) * 100));
            return (
              <div
                key={ach.id}
                className={`p-3 rounded-xl border transition-all ${
                  ach.isUnlocked
                    ? 'bg-slate-900/90 border-slate-700/80 shadow-sm'
                    : 'bg-slate-950/60 border-slate-800/60 opacity-60'
                }`}
              >
                <div className="flex items-start justify-between gap-3">
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      <h4 className="font-bold text-xs text-white">{ach.title}</h4>
                      {ach.isUnlocked ? (
                        <CheckCircle2 size={13} className="text-sky-400" />
                      ) : (
                        <Lock size={12} className="text-slate-500" />
                      )}
                    </div>
                    <p className="text-[11px] text-slate-400 mt-1 leading-relaxed">
                      {ach.description}
                    </p>
                    {ach.unlockedAt && (
                      <span className="text-[10px] text-emerald-400 font-medium mt-1 inline-block">
                        Earned on {ach.unlockedAt}
                      </span>
                    )}
                  </div>
                  <span className="text-xs font-bold font-mono text-slate-300">
                    {ach.currentProgress}/{ach.targetProgress}
                  </span>
                </div>

                <div className="mt-2 w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
                  <div
                    className={`h-full rounded-full transition-all duration-300 ${
                      ach.isUnlocked ? 'bg-sky-400' : 'bg-slate-600'
                    }`}
                    style={{ width: `${percent}%` }}
                  />
                </div>
              </div>
            );
          })}
        </div>

        <button
          onClick={onClose}
          className="mt-4 w-full py-2 bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-white rounded-xl transition-colors"
        >
          Done
        </button>
      </div>
    </div>
  );
};
