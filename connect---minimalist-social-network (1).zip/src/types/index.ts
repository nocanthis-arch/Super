export type VerificationType = 'none' | 'blue' | 'yellow' | 'red';
export type LikeState = 'none' | 'blue' | 'red';
export type CreativeField = 'Developer' | 'Designer' | 'Writer' | 'Generalist' | 'Sound Architect' | 'Photographer' | 'Product Lead';

export interface User {
  id: string;
  name: string;
  username: string;
  avatar: string;
  creativeField: CreativeField;
  bio: string;
  stats: {
    activeUsageHours: number;
    connectionsCount: number;
    totalPostViews: number;
    isTopCreator?: boolean;
  };
  connectionStatus: 'connect' | 'pending' | 'connected';
}

export interface CommentItem {
  id: string;
  postId: string;
  author: {
    id: string;
    name: string;
    username: string;
    avatar: string;
    creativeField: CreativeField;
    verification: VerificationType;
  };
  content: string;
  createdAt: string; // ISO date string
  isAuthorReply?: boolean;
  replyToUsername?: string;
  replies?: CommentItem[];
}

export interface Post {
  id: string;
  author: User;
  content: string;
  image?: string;
  createdAt: string; // ISO date string
  likesCount: number;
  superLikesCount: number;
  userLikeState: LikeState;
  comments: CommentItem[];
  sharesCount: number;
  viewsCount: number;
  isSponsored?: boolean;
  sponsoredData?: {
    companyName: string;
    companyLogo: string;
    format: 'text' | 'photo' | 'video';
    mediaUrl?: string;
    headline: string;
    ctaText: string;
    ctaUrl: string;
  };
}

export interface Story {
  id: string;
  user: User;
  mediaUrl: string;
  caption?: string;
  createdAt: string;
  isViewed: boolean;
}

export interface Achievement {
  id: string;
  title: string;
  description: string;
  icon: string;
  category: 'hours' | 'connections' | 'engagement' | 'creator';
  currentProgress: number;
  targetProgress: number;
  isUnlocked: boolean;
  unlockedAt?: string;
}

export interface DirectMessage {
  id: string;
  senderId: string;
  text: string;
  timestamp: string;
}

export interface Conversation {
  id: string;
  user: User;
  lastMessage: string;
  lastTime: string;
  unreadCount: number;
  messages: DirectMessage[];
}
