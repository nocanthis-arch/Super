/**
 * Complete, production-grade Flutter & Dart source code for "Connect"
 * Structured by files for developer inspection, copy, and export.
 */

export interface FlutterSourceFile {
  path: string;
  filename: string;
  category: 'core' | 'models' | 'widgets' | 'screens' | 'utils' | 'config';
  code: string;
  description: string;
}

export const FLUTTER_FILES: FlutterSourceFile[] = [
  {
    path: 'pubspec.yaml',
    filename: 'pubspec.yaml',
    category: 'config',
    description: 'Flutter project specification, assets, and dependencies.',
    code: `name: connect
description: A clean, minimalist social networking mobile app optimized for low-spec devices.
publish_to: 'none'
version: 1.0.0+1

environment:
  sdk: '>=3.0.0 <4.0.0'

dependencies:
  flutter:
    sdk: flutter
  intl: ^0.19.0
  cached_network_image: ^3.3.1
  flutter_staggered_animations: ^1.1.1
  share_plus: ^9.0.0

dev_dependencies:
  flutter_test:
    sdk: flutter
  flutter_lints: ^3.0.0

flutter:
  uses-material-design: true
`,
  },
  {
    path: 'lib/main.dart',
    filename: 'main.dart',
    category: 'core',
    description: 'Application entry point, navigation shell, and theme setup.',
    code: `import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'theme/app_theme.dart';
import 'screens/feed_screen.dart';
import 'screens/messages_screen.dart';
import 'screens/profile_screen.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setPreferredOrientations([
    DeviceOrientation.portraitUp,
    DeviceOrientation.portraitDown,
  ]);
  SystemChrome.setSystemUIOverlayStyle(
    const SystemUiOverlayStyle(
      statusBarColor: Colors.transparent,
      statusBarIconBrightness: Brightness.light,
      systemNavigationBarColor: Color(0xFF0F1117),
      systemNavigationBarIconBrightness: Brightness.light,
    ),
  );
  runApp(const ConnectApp());
}

class ConnectApp extends StatelessWidget {
  const ConnectApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Connect',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.darkTheme,
      home: const MainNavigationShell(),
    );
  }
}

class MainNavigationShell extends StatefulWidget {
  const MainNavigationShell({super.key});

  @override
  State<MainNavigationShell> createState() => _MainNavigationShellState();
}

class _MainNavigationShellState extends State<MainNavigationShell> {
  int _currentIndex = 0;

  final List<Widget> _screens = const [
    FeedScreen(),
    MessagesScreen(),
    ProfileScreen(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: IndexedStack(
        index: _currentIndex,
        children: _screens,
      ),
      bottomNavigationBar: Container(
        decoration: const BoxDecoration(
          color: Color(0xFF0F1117),
          border: Border(
            top: BorderSide(color: Color(0xFF1E2330), width: 0.8),
          ),
        ),
        child: SafeArea(
          child: SizedBox(
            height: 60,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                _buildNavItem(
                  index: 0,
                  icon: Icons.home_filled,
                  label: 'Home',
                ),
                _buildNavItem(
                  index: 1,
                  icon: Icons.chat_bubble_outline_rounded,
                  activeIcon: Icons.chat_bubble_rounded,
                  label: 'Messages',
                  badgeCount: 2,
                ),
                _buildNavItem(
                  index: 2,
                  icon: Icons.person_outline_rounded,
                  activeIcon: Icons.person_rounded,
                  label: 'Profile',
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildNavItem({
    required int index,
    required IconData icon,
    IconData? activeIcon,
    required String label,
    int badgeCount = 0,
  }) {
    final isSelected = _currentIndex === index;
    final color = isSelected ? const Color(0xFF38BDF8) : const Color(0xFF64748B);

    return InkWell(
      onTap: () {
        if (_currentIndex != index) {
          HapticFeedback.selectionClick();
          setState(() {
            _currentIndex = index;
          });
        }
      },
      borderRadius: BorderRadius.circular(16),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
        child: Stack(
          clipBehavior: Clip.none,
          children: [
            Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(
                  isSelected ? (activeIcon ?? icon) : icon,
                  color: color,
                  size: 24,
                ),
                const SizedBox(height: 2),
                Text(
                  label,
                  style: TextStyle(
                    fontSize: 10,
                    fontWeight: isSelected ? FontWeight.w600 : FontWeight.w400,
                    color: color,
                  ),
                ),
              ],
            ),
            if (badgeCount > 0)
              Positioned(
                top: -2,
                right: -6,
                child: Container(
                  padding: const EdgeInsets.all(4),
                  decoration: const BoxDecoration(
                    color: Color(0xFFEF4444),
                    shape: BoxShape.circle,
                  ),
                  constraints: const BoxConstraints(minWidth: 14, minHeight: 14),
                  child: Text(
                    badgeCount.toString(),
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 8,
                      fontWeight: FontWeight.bold,
                    ),
                    textAlign: TextAlign.center,
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }
}
`,
  },
  {
    path: 'lib/theme/app_theme.dart',
    filename: 'app_theme.dart',
    category: 'core',
    description: 'Minimalist dark design system tuned for low-memory devices.',
    code: `import 'package:flutter/material.dart';

class AppTheme {
  static const Color background = Color(0xFF090A0F);
  static const Color surface = Color(0xFF13161F);
  static const Color surfaceElevated = Color(0xFF1B202E);
  static const Color border = Color(0xFF222938);
  static const Color primaryBlue = Color(0xFF38BDF8);
  static const Color superLikeRed = Color(0xFFEF4444);
  static const Color verificationYellow = Color(0xFFEAB308);
  static const Color textPrimary = Color(0xFFF1F5F9);
  static const Color textSecondary = Color(0xFF94A3B8);
  static const Color textMuted = Color(0xFF64748B);

  static final ThemeData darkTheme = ThemeData(
    useMaterial3: true,
    brightness: Brightness.dark,
    scaffoldBackgroundColor: background,
    canvasColor: surface,
    fontFamily: 'Roboto',
    cardColor: surface,
    dividerColor: border,
    appBarTheme: const AppBarTheme(
      backgroundColor: background,
      elevation: 0,
      scrolledUnderElevation: 0,
      centerTitle: false,
      titleTextStyle: TextStyle(
        color: textPrimary,
        fontSize: 20,
        fontWeight: FontWeight.w700,
        letterSpacing: -0.5,
      ),
      iconTheme: IconThemeData(color: textPrimary),
    ),
    colorScheme: const ColorScheme.dark(
      primary: primaryBlue,
      secondary: superLikeRed,
      surface: surface,
      onPrimary: Colors.white,
      onSurface: textPrimary,
      onError: Colors.white,
    ),
  );
}
`,
  },
  {
    path: 'lib/models/models.dart',
    filename: 'models.dart',
    category: 'models',
    description: 'Data models for Users, Posts, Comments, Stories, and Achievements.',
    code: `enum VerificationType { none, blue, yellow, red }
enum LikeState { none, blue, red }

class User {
  final String id;
  final String name;
  final String username;
  final String avatar;
  final String creativeField;
  final String bio;
  final int activeUsageHours;
  final int connectionsCount;
  final int totalPostViews;
  final bool isTopCreator;
  String connectionStatus; // 'connect', 'pending', 'connected'

  User({
    required this.id,
    required this.name,
    required this.username,
    required this.avatar,
    required this.creativeField,
    required this.bio,
    this.activeUsageHours = 0,
    this.connectionsCount = 0,
    this.totalPostViews = 0,
    this.isTopCreator = false,
    this.connectionStatus = 'connect',
  });

  VerificationType get verificationType {
    if (isTopCreator || (totalPostViews >= 1000 && connectionsCount >= 50 && activeUsageHours >= 100)) {
      return VerificationType.red;
    }
    if (connectionsCount >= 50) {
      return VerificationType.yellow;
    }
    if (activeUsageHours >= 100) {
      return VerificationType.blue;
    }
    return VerificationType.none;
  }
}

class Comment {
  final String id;
  final String postId;
  final User author;
  final String content;
  final DateTime createdAt;
  final bool isAuthorReply;
  final String? replyToUsername;
  final List<Comment> replies;

  Comment({
    required this.id,
    required this.postId,
    required this.author,
    required this.content,
    required this.createdAt,
    this.isAuthorReply = false,
    this.replyToUsername,
    this.replies = const [],
  });
}

class Post {
  final String id;
  final User author;
  String content;
  String? image;
  final DateTime createdAt;
  int likesCount;
  int superLikesCount;
  LikeState userLikeState;
  final List<Comment> comments;
  int sharesCount;
  int viewsCount;
  final bool isSponsored;
  final SponsoredAdData? sponsoredData;

  Post({
    required this.id,
    required this.author,
    required this.content,
    this.image,
    required this.createdAt,
    this.likesCount = 0,
    this.superLikesCount = 0,
    this.userLikeState = LikeState.none,
    required this.comments,
    this.sharesCount = 0,
    this.viewsCount = 0,
    this.isSponsored = false,
    this.sponsoredData,
  });

  bool get isEditable {
    final diff = DateTime.now().difference(createdAt);
    return diff.inHours < 1 && !diff.isNegative;
  }
}

class SponsoredAdData {
  final String companyName;
  final String companyLogo;
  final String format; // 'text', 'photo', 'video'
  final String? mediaUrl;
  final String headline;
  final String ctaText;
  final String ctaUrl;

  SponsoredAdData({
    required this.companyName,
    required this.companyLogo,
    required this.format,
    this.mediaUrl,
    required this.headline,
    required this.ctaText,
    required this.ctaUrl,
  });
}

class Story {
  final String id;
  final User user;
  final String mediaUrl;
  final String? caption;
  final DateTime createdAt;
  bool isViewed;

  Story({
    required this.id,
    required this.user,
    required this.mediaUrl,
    this.caption,
    required this.createdAt,
    this.isViewed = false,
  });
}

class Achievement {
  final String id;
  final String title;
  final String description;
  final IconData icon;
  final int currentProgress;
  final int targetProgress;
  final bool isUnlocked;
  final String? unlockedAt;

  Achievement({
    required this.id,
    required this.title,
    required this.description,
    required this.icon,
    required this.currentProgress,
    required this.targetProgress,
    required this.isUnlocked,
    this.unlockedAt,
  });
}
`,
  },
  {
    path: 'lib/utils/formatters.dart',
    filename: 'formatters.dart',
    category: 'utils',
    description: 'Exact timestamp formatting and share link generators.',
    code: `import 'package:intl/intl.dart';

class ConnectFormatters {
  /// Format timestamp:
  /// - Exact time if posted today (e.g. "14:25")
  /// - "Yesterday" if posted yesterday
  /// - Full Date if older (e.g. "Oct 15, 2026")
  static String formatPostTimestamp(DateTime dateTime, [DateTime? reference]) {
    final now = reference ?? DateTime.now();

    final isSameDay = dateTime.year == now.year &&
        dateTime.month == now.month &&
        dateTime.day == now.day;

    if (isSameDay) {
      return DateFormat('HH:mm').format(dateTime);
    }

    final yesterday = now.subtract(const Duration(days: 1));
    final isYesterday = dateTime.year == yesterday.year &&
        dateTime.month == yesterday.month &&
        dateTime.day == yesterday.day;

    if (isYesterday) {
      return 'Yesterday';
    }

    return DateFormat('MMM d, y').format(dateTime);
  }

  static String generateShareableLink(String postId) {
    return 'https://connect.social/p/$postId';
  }

  static String formatMetricNumber(int count) {
    if (count >= 1000000) {
      return '\${(count / 1000000).toStringAsFixed(1)}M';
    } else if (count >= 1000) {
      return '\${(count / 1000).toStringAsFixed(1)}k';
    }
    return count.toString();
  }
}
`,
  },
  {
    path: 'lib/widgets/verification_tick.dart',
    filename: 'verification_tick.dart',
    category: 'widgets',
    description: 'Dynamic verification ticks (Blue, Yellow, Red) based on engagement.',
    code: `import 'package:flutter/material.dart';
import '../models/models.dart';

class VerificationTick extends StatelessWidget {
  final VerificationType type;
  final double size;

  const VerificationTick({
    super.key,
    required this.type,
    this.size = 15.0,
  });

  @override
  Widget build(BuildContext context) {
    if (type == VerificationType.none) {
      return const SizedBox.shrink();
    }

    Color badgeColor;
    IconData iconData = Icons.check;

    switch (type) {
      case VerificationType.blue:
        badgeColor = const Color(0xFF38BDF8); // 100+ active hours
        break;
      case VerificationType.yellow:
        badgeColor = const Color(0xFFEAB308); // Higher community connection milestone
        break;
      case VerificationType.red:
        badgeColor = const Color(0xFFEF4444); // Top creator & active collaborator
        iconData = Icons.star;
        break;
      default:
        return const SizedBox.shrink();
    }

    return Tooltip(
      message: _getTooltipMessage(type),
      child: Container(
        margin: const EdgeInsets.only(left: 4),
        width: size,
        height: size,
        decoration: BoxDecoration(
          color: badgeColor,
          shape: BoxShape.circle,
        ),
        child: Center(
          child: Icon(
            iconData,
            size: size * 0.7,
            color: Colors.white,
          ),
        ),
      ),
    );
  }

  String _getTooltipMessage(VerificationType type) {
    switch (type) {
      case VerificationType.blue:
        return 'Blue Tick: 100+ hours active app usage';
      case VerificationType.yellow:
        return 'Yellow Tick: 50+ community connections';
      case VerificationType.red:
        return 'Red Tick: Top creator & collaborative vanguard';
      default:
        return '';
    }
  }
}
`,
  },
  {
    path: 'lib/widgets/super_like_animator.dart',
    filename: 'super_like_animator.dart',
    category: 'widgets',
    description: 'Hardware-accelerated Super Like heart burst particle animation.',
    code: `import 'dart:math';
import 'package:flutter/material.dart';

class SuperLikeAnimator extends StatefulWidget {
  final VoidCallback onComplete;

  const SuperLikeAnimator({super.key, required this.onComplete});

  @override
  State<SuperLikeAnimator> createState() => _SuperLikeAnimatorState();
}

class _SuperLikeAnimatorState extends State<SuperLikeAnimator>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _scaleAnimation;
  late Animation<double> _opacityAnimation;
  late List<Particle> _particles;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 700),
    );

    _scaleAnimation = TweenSequence<double>([
      TweenSequenceItem(tween: Tween(begin: 0.2, end: 1.5).chain(CurveTween(curve: Curves.easeOutBack)), weight: 50),
      TweenSequenceItem(tween: Tween(begin: 1.5, end: 1.0).chain(CurveTween(curve: Curves.easeInOut)), weight: 50),
    ]).animate(_controller);

    _opacityAnimation = Tween<double>(begin: 1.0, end: 0.0).animate(
      CurvedAnimation(parent: _controller, curve: const Interval(0.65, 1.0, curve: Curves.easeOut)),
    );

    final random = Random();
    _particles = List.generate(8, (i) {
      final angle = (i * 45) * (pi / 180);
      final speed = 35.0 + random.nextDouble() * 25.0;
      return Particle(angle: angle, speed: speed);
    });

    _controller.forward().then((_) => widget.onComplete());
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _controller,
      builder: (context, child) {
        return Opacity(
          opacity: _opacityAnimation.value,
          child: Stack(
            alignment: Alignment.center,
            children: [
              ..._particles.map((p) {
                final progress = _controller.value;
                final dx = cos(p.angle) * p.speed * progress;
                final dy = sin(p.angle) * p.speed * progress;
                return Transform.translate(
                  offset: Offset(dx, dy),
                  child: Container(
                    width: 4,
                    height: 4,
                    decoration: const BoxDecoration(
                      color: Color(0xFFEF4444),
                      shape: BoxShape.circle,
                    ),
                  ),
                );
              }),
              Transform.scale(
                scale: _scaleAnimation.value,
                child: const Icon(
                  Icons.favorite,
                  color: Color(0xFFEF4444),
                  size: 32,
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}

class Particle {
  final double angle;
  final double speed;
  Particle({required this.angle, required this.speed});
}
`,
  },
  {
    path: 'lib/widgets/post_card.dart',
    filename: 'post_card.dart',
    category: 'widgets',
    description: 'Post card layout with single-tap blue heart, double-tap red super-like, threaded comments, share link, and post management.',
    code: `import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../models/models.dart';
import '../utils/formatters.dart';
import 'verification_tick.dart';
import 'super_like_animator.dart';
import 'threaded_comment_sheet.dart';

class PostCard extends StatefulWidget {
  final Post post;
  final String currentUserId;
  final Function(Post) onUpdate;
  final Function(String) onDelete;

  const PostCard({
    super.key,
    required this.post,
    required this.currentUserId,
    required this.onUpdate,
    required this.onDelete,
  });

  @override
  State<PostCard> createState() => _PostCardState();
}

class _PostCardState extends State<PostCard> {
  bool _showSuperLikeAnimation = false;
  DateTime? _lastTapTime;

  void _handleHeartTap() {
    final now = DateTime.now();
    // Check for double tap (< 300ms)
    if (_lastTapTime != null && now.difference(_lastTapTime!).inMilliseconds < 300) {
      _triggerSuperLike();
    } else {
      _toggleSingleTapLike();
    }
    _lastTapTime = now;
  }

  void _toggleSingleTapLike() {
    HapticFeedback.lightImpact();
    setState(() {
      if (widget.post.userLikeState == LikeState.none) {
        widget.post.userLikeState = LikeState.blue;
        widget.post.likesCount++;
      } else {
        widget.post.userLikeState = LikeState.none;
        widget.post.likesCount = (widget.post.likesCount - 1).clamp(0, 999999);
      }
    });
    widget.onUpdate(widget.post);
  }

  void _triggerSuperLike() {
    HapticFeedback.heavyImpact();
    setState(() {
      if (widget.post.userLikeState != LikeState.red) {
        widget.post.superLikesCount++;
        if (widget.post.userLikeState == LikeState.none) {
          widget.post.likesCount++;
        }
      }
      widget.post.userLikeState = LikeState.red;
      _showSuperLikeAnimation = true;
    });
    widget.onUpdate(widget.post);
  }

  void _handleShare() {
    final shareUrl = ConnectFormatters.generateShareableLink(widget.post.id);
    Clipboard.setData(ClipboardData(text: shareUrl));
    widget.post.sharesCount++;
    widget.onUpdate(widget.post);

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            const Icon(Icons.link, color: Color(0xFF38BDF8), size: 18),
            const SizedBox(width: 8),
            Expanded(
              child: Text(
                'Link copied: $shareUrl',
                style: const TextStyle(fontSize: 12),
                overflow: TextOverflow.ellipsis,
              ),
            ),
          ],
        ),
        backgroundColor: const Color(0xFF1B202E),
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
        duration: const Duration(seconds: 2),
      ),
    );
  }

  void _openComments() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: const Color(0xFF13161F),
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (ctx) => ThreadedCommentSheet(
        post: widget.post,
        currentUserId: widget.currentUserId,
        onCommentAdded: () {
          setState(() {});
          widget.onUpdate(widget.post);
        },
      ),
    );
  }

  void _showPostOptionsMenu() {
    final isAuthor = widget.post.author.id == widget.currentUserId;
    if (!isAuthor) return;

    final isWithin1Hour = widget.post.isEditable;

    showModalBottomSheet(
      context: context,
      backgroundColor: const Color(0xFF13161F),
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(18)),
      ),
      builder: (ctx) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              margin: const EdgeInsets.symmetric(vertical: 8),
              width: 36,
              height: 4,
              decoration: BoxDecoration(
                color: const Color(0xFF333B4F),
                borderRadius: BorderRadius.circular(2),
              ),
            ),
            ListTile(
              leading: Icon(
                Icons.edit_note_rounded,
                color: isWithin1Hour ? const Color(0xFF38BDF8) : Colors.grey,
              ),
              title: Text(
                widget.post.image != null ? 'Edit Caption' : 'Edit Text Content',
                style: TextStyle(
                  color: isWithin1Hour ? Colors.white : Colors.grey,
                  fontSize: 14,
                ),
              ),
              subtitle: Text(
                isWithin1Hour
                    ? 'Allowed up to 1 hour after posting'
                    : 'Editing locked: post is older than 1 hour',
                style: const TextStyle(fontSize: 11, color: Color(0xFF94A3B8)),
              ),
              enabled: isWithin1Hour,
              onTap: isWithin1Hour
                  ? () {
                      Navigator.pop(ctx);
                      _showEditDialog();
                    }
                  : null,
            ),
            if (widget.post.image != null)
              ListTile(
                leading: const Icon(Icons.image_not_supported_outlined, color: Colors.amber, size: 20),
                title: const Text('Delete Image Only', style: TextStyle(fontSize: 14)),
                onTap: () {
                  Navigator.pop(ctx);
                  setState(() {
                    widget.post.image = null;
                  });
                  widget.onUpdate(widget.post);
                },
              ),
            ListTile(
              leading: const Icon(Icons.delete_outline_rounded, color: Color(0xFFEF4444)),
              title: const Text('Permanently Delete Post', style: TextStyle(color: Color(0xFFEF4444), fontSize: 14)),
              onTap: () {
                Navigator.pop(ctx);
                widget.onDelete(widget.post.id);
              },
            ),
          ],
        ),
      ),
    );
  }

  void _showEditDialog() {
    final controller = TextEditingController(text: widget.post.content);
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: const Color(0xFF1B202E),
        title: Text(
          widget.post.image != null ? 'Edit Caption' : 'Edit Post',
          style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
        ),
        content: TextField(
          controller: controller,
          maxLines: 4,
          style: const TextStyle(fontSize: 14, color: Colors.white),
          decoration: InputDecoration(
            hintText: 'Enter new content...',
            hintStyle: const TextStyle(color: Color(0xFF64748B)),
            filled: true,
            fillColor: const Color(0xFF13161F),
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(10),
              borderSide: BorderSide.none,
            ),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('Cancel', style: TextStyle(color: Color(0xFF94A3B8))),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: const Color(0xFF38BDF8),
              foregroundColor: Colors.black,
            ),
            onPressed: () {
              if (controller.text.trim().isNotEmpty) {
                setState(() {
                  widget.post.content = controller.text.trim();
                });
                widget.onUpdate(widget.post);
              }
              Navigator.pop(ctx);
            },
            child: const Text('Save'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final isAuthor = widget.post.author.id == widget.currentUserId;
    final formattedTime = ConnectFormatters.formatPostTimestamp(widget.post.createdAt);

    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.all(16),
      decoration: const BoxDecoration(
        color: Color(0xFF13161F),
        border: Border(
          bottom: BorderSide(color: Color(0xFF1E2330), width: 0.8),
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Header: Avatar, Display Name, Username, Creative Tag, Timestamp, 3-dots
          Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              CircleAvatar(
                radius: 19,
                backgroundImage: NetworkImage(widget.post.author.avatar),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Flexible(
                          child: Text(
                            widget.post.author.name,
                            style: const TextStyle(
                              fontSize: 14,
                              fontWeight: FontWeight.w700,
                              color: Color(0xFFF1F5F9),
                            ),
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                        VerificationTick(type: widget.post.author.verificationType),
                        const SizedBox(width: 6),
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                          decoration: BoxDecoration(
                            color: const Color(0xFF1E2330),
                            borderRadius: BorderRadius.circular(4),
                          ),
                          child: Text(
                            widget.post.author.creativeField,
                            style: const TextStyle(
                              fontSize: 9,
                              fontWeight: FontWeight.w600,
                              color: Color(0xFF94A3B8),
                            ),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 1),
                    Row(
                      children: [
                        Text(
                          '@\${widget.post.author.username}',
                          style: const TextStyle(
                            fontSize: 12,
                            color: Color(0xFF64748B),
                          ),
                        ),
                        const Text(' · ', style: TextStyle(color: Color(0xFF475569))),
                        Text(
                          formattedTime,
                          style: const TextStyle(
                            fontSize: 11,
                            color: Color(0xFF64748B),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              if (isAuthor)
                IconButton(
                  icon: const Icon(Icons.more_horiz, color: Color(0xFF64748B), size: 20),
                  onPressed: _showPostOptionsMenu,
                  padding: EdgeInsets.zero,
                  constraints: const BoxConstraints(),
                ),
            ],
          ),

          const SizedBox(height: 12),

          // Post Text Body
          Text(
            widget.post.content,
            style: const TextStyle(
              fontSize: 14,
              height: 1.45,
              color: Color(0xFFE2E8F0),
            ),
          ),

          // Optional Image attachment
          if (widget.post.image != null) ...[
            const SizedBox(height: 12),
            ClipRRect(
              borderRadius: BorderRadius.circular(12),
              child: Image.network(
                widget.post.image!,
                width: double.infinity,
                fit: BoxFit.cover,
                errorBuilder: (ctx, err, stack) => const SizedBox.shrink(),
              ),
            ),
          ],

          const SizedBox(height: 14),

          // Interaction Bar: Like (Heart), Comment, Share, View Counter
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              // Like Button (Heart)
              InkWell(
                onTap: _handleHeartTap,
                borderRadius: BorderRadius.circular(20),
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  child: Row(
                    children: [
                      Stack(
                        alignment: Alignment.center,
                        children: [
                          Icon(
                            widget.post.userLikeState == LikeState.none
                                ? Icons.favorite_border
                                : Icons.favorite,
                            size: 20,
                            color: widget.post.userLikeState == LikeState.red
                                ? const Color(0xFFEF4444) // Double tap Super Like
                                : widget.post.userLikeState == LikeState.blue
                                    ? const Color(0xFF38BDF8) // Single tap Like
                                    : const Color(0xFF64748B),
                          ),
                          if (_showSuperLikeAnimation)
                            SuperLikeAnimator(
                              onComplete: () {
                                if (mounted) {
                                  setState(() {
                                    _showSuperLikeAnimation = false;
                                  });
                                }
                              },
                            ),
                        ],
                      ),
                      const SizedBox(width: 6),
                      Text(
                        ConnectFormatters.formatMetricNumber(widget.post.likesCount),
                        style: TextStyle(
                          fontSize: 12,
                          fontWeight: FontWeight.w500,
                          color: widget.post.userLikeState == LikeState.red
                              ? const Color(0xFFEF4444)
                              : widget.post.userLikeState == LikeState.blue
                                  ? const Color(0xFF38BDF8)
                                  : const Color(0xFF94A3B8),
                        ),
                      ),
                    ],
                  ),
                ),
              ),

              // Comment Button
              InkWell(
                onTap: _openComments,
                borderRadius: BorderRadius.circular(20),
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  child: Row(
                    children: [
                      const Icon(Icons.mode_comment_outlined, size: 19, color: Color(0xFF64748B)),
                      const SizedBox(width: 6),
                      Text(
                        widget.post.comments.length.toString(),
                        style: const TextStyle(fontSize: 12, color: Color(0xFF94A3B8)),
                      ),
                    ],
                  ),
                ),
              ),

              // Share Button
              InkWell(
                onTap: _handleShare,
                borderRadius: BorderRadius.circular(20),
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  child: Row(
                    children: [
                      const Icon(Icons.share_outlined, size: 19, color: Color(0xFF64748B)),
                      const SizedBox(width: 6),
                      Text(
                        widget.post.sharesCount.toString(),
                        style: const TextStyle(fontSize: 12, color: Color(0xFF94A3B8)),
                      ),
                    ],
                  ),
                ),
              ),

              // View Counter
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                child: Row(
                  children: [
                    const Icon(Icons.remove_red_eye_outlined, size: 18, color: Color(0xFF475569)),
                    const SizedBox(width: 5),
                    Text(
                      ConnectFormatters.formatMetricNumber(widget.post.viewsCount),
                      style: const TextStyle(fontSize: 12, color: Color(0xFF64748B)),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
`,
  },
  {
    path: 'lib/widgets/sponsored_ad_card.dart',
    filename: 'sponsored_ad_card.dart',
    category: 'widgets',
    description: 'Native feed advertisement card with company branding, format handling, and interactive bar.',
    code: `import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../models/models.dart';
import '../utils/formatters.dart';

class SponsoredAdCard extends StatefulWidget {
  final Post post;

  const SponsoredAdCard({super.key, required this.post});

  @override
  State<SponsoredAdCard> createState() => _SponsoredAdCardState();
}

class _SponsoredAdCardState extends State<SponsoredAdCard> {
  bool _isLiked = false;

  @override
  Widget build(BuildContext context) {
    final ad = widget.post.sponsoredData;
    if (ad == null) return const SizedBox.shrink();

    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.all(16),
      decoration: const BoxDecoration(
        color: Color(0xFF13161F),
        border: Border(
          bottom: BorderSide(color: Color(0xFF1E2330), width: 0.8),
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Ad Header: Company Logo, Name, "Sponsored" tag
          Row(
            children: [
              ClipRRect(
                borderRadius: BorderRadius.circular(8),
                child: Image.network(
                  ad.companyLogo,
                  width: 38,
                  height: 38,
                  fit: BoxFit.cover,
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      ad.companyName,
                      style: const TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.w700,
                        color: Color(0xFFF1F5F9),
                      ),
                    ),
                    Row(
                      children: [
                        const Text(
                          'Sponsored',
                          style: TextStyle(
                            fontSize: 11,
                            fontWeight: FontWeight.w500,
                            color: Color(0xFF38BDF8),
                          ),
                        ),
                        const Text(' · ', style: TextStyle(color: Color(0xFF475569))),
                        Text(
                          ad.format.toUpperCase(),
                          style: const TextStyle(
                            fontSize: 10,
                            fontWeight: FontWeight.bold,
                            color: Color(0xFF64748B),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFF1E2330),
                  foregroundColor: const Color(0xFF38BDF8),
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                  minimumSize: Size.zero,
                  tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                  elevation: 0,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(6)),
                ),
                onPressed: () {},
                child: Text(ad.ctaText, style: const TextStyle(fontSize: 11, fontWeight: FontWeight.bold)),
              ),
            ],
          ),

          const SizedBox(height: 12),

          // Ad Text Content
          Text(
            widget.post.content,
            style: const TextStyle(
              fontSize: 14,
              height: 1.45,
              color: Color(0xFFE2E8F0),
            ),
          ),

          // Ad Media (Photo or simulated video banner)
          if (ad.mediaUrl != null) ...[
            const SizedBox(height: 12),
            ClipRRect(
              borderRadius: BorderRadius.circular(10),
              child: Stack(
                alignment: Alignment.center,
                children: [
                  Image.network(
                    ad.mediaUrl!,
                    width: double.infinity,
                    height: 190,
                    fit: BoxFit.cover,
                  ),
                  if (ad.format == 'video')
                    Container(
                      width: 48,
                      height: 48,
                      decoration: BoxDecoration(
                        color: Colors.black.withOpacity(0.6),
                        shape: BoxShape.circle,
                      ),
                      child: const Icon(Icons.play_arrow_rounded, color: Colors.white, size: 30),
                    ),
                ],
              ),
            ),
          ],

          const SizedBox(height: 14),

          // Standard Like, Comment, and Share Buttons
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              InkWell(
                onTap: () {
                  HapticFeedback.lightImpact();
                  setState(() => _isLiked = !_isLiked);
                },
                child: Row(
                  children: [
                    Icon(
                      _isLiked ? Icons.favorite : Icons.favorite_border,
                      size: 20,
                      color: _isLiked ? const Color(0xFF38BDF8) : const Color(0xFF64748B),
                    ),
                    const SizedBox(width: 6),
                    Text(
                      (_isLiked ? widget.post.likesCount + 1 : widget.post.likesCount).toString(),
                      style: TextStyle(
                        fontSize: 12,
                        color: _isLiked ? const Color(0xFF38BDF8) : const Color(0xFF94A3B8),
                      ),
                    ),
                  ],
                ),
              ),
              Row(
                children: [
                  const Icon(Icons.mode_comment_outlined, size: 19, color: Color(0xFF64748B)),
                  const SizedBox(width: 6),
                  Text(
                    widget.post.comments.length.toString(),
                    style: const TextStyle(fontSize: 12, color: Color(0xFF94A3B8)),
                  ),
                ],
              ),
              InkWell(
                onTap: () {
                  final link = ConnectFormatters.generateShareableLink(widget.post.id);
                  Clipboard.setData(ClipboardData(text: link));
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('Sponsored link copied to clipboard')),
                  );
                },
                child: Row(
                  children: [
                    const Icon(Icons.share_outlined, size: 19, color: Color(0xFF64748B)),
                    const SizedBox(width: 6),
                    Text(
                      widget.post.sharesCount.toString(),
                      style: const TextStyle(fontSize: 12, color: Color(0xFF94A3B8)),
                    ),
                  ],
                ),
              ),
              Row(
                children: [
                  const Icon(Icons.remove_red_eye_outlined, size: 18, color: Color(0xFF475569)),
                  const SizedBox(width: 5),
                  Text(
                    ConnectFormatters.formatMetricNumber(widget.post.viewsCount),
                    style: const TextStyle(fontSize: 12, color: Color(0xFF64748B)),
                  ),
                ],
              ),
            ],
          ),
        ],
      ),
    );
  }
}
`,
  },
  {
    path: 'lib/widgets/stories_carousel.dart',
    filename: 'stories_carousel.dart',
    category: 'widgets',
    description: 'Horizontal story carousel with unviewed gradient border and story viewer modal.',
    code: `import 'package:flutter/material.dart';
import '../models/models.dart';

class StoriesCarousel extends StatelessWidget {
  final List<Story> stories;
  final User currentUser;
  final Function(Story) onStoryTap;
  final VoidCallback onAddStory;

  const StoriesCarousel({
    super.key,
    required this.stories,
    required this.currentUser,
    required this.onStoryTap,
    required this.onAddStory,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 104,
      padding: const EdgeInsets.symmetric(vertical: 10),
      decoration: const BoxDecoration(
        color: Color(0xFF090A0F),
        border: Border(bottom: BorderSide(color: Color(0xFF1E2330), width: 0.8)),
      ),
      child: ListView.separated(
        padding: const EdgeInsets.symmetric(horizontal: 16),
        scrollDirection: Axis.horizontal,
        itemCount: stories.length + 1,
        separatorBuilder: (_, __) => const SizedBox(width: 14),
        itemBuilder: (context, index) {
          if (index == 0) {
            return _buildYourStoryButton();
          }
          final story = stories[index - 1];
          return _buildStoryItem(context, story);
        },
      ),
    );
  }

  Widget _buildYourStoryButton() {
    return Column(
      children: [
        Stack(
          children: [
            CircleAvatar(
              radius: 27,
              backgroundImage: NetworkImage(currentUser.avatar),
            ),
            Positioned(
              bottom: 0,
              right: 0,
              child: GestureDetector(
                onTap: onAddStory,
                child: Container(
                  width: 20,
                  height: 20,
                  decoration: const BoxDecoration(
                    color: Color(0xFF38BDF8),
                    shape: BoxShape.circle,
                  ),
                  child: const Icon(Icons.add, color: Colors.black, size: 14),
                ),
              ),
            ),
          ],
        ),
        const SizedBox(height: 4),
        const Text(
          'Your Story',
          style: TextStyle(fontSize: 11, color: Color(0xFF94A3B8)),
        ),
      ],
    );
  }

  Widget _buildStoryItem(BuildContext context, Story story) {
    return GestureDetector(
      onTap: () => onStoryTap(story),
      child: Column(
        children: [
          Container(
            padding: const EdgeInsets.all(2.5),
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              border: Border.all(
                color: story.isViewed ? const Color(0xFF333B4F) : const Color(0xFF38BDF8),
                width: 2,
              ),
            ),
            child: CircleAvatar(
              radius: 25,
              backgroundImage: NetworkImage(story.user.avatar),
            ),
          ),
          const SizedBox(height: 4),
          SizedBox(
            width: 58,
            child: Text(
              story.user.name.split(' ').first,
              style: const TextStyle(
                fontSize: 11,
                color: Color(0xFFE2E8F0),
              ),
              overflow: TextOverflow.ellipsis,
              textAlign: TextAlign.center,
            ),
          ),
        ],
      ),
    );
  }
}
`,
  },
  {
    path: 'lib/widgets/threaded_comment_sheet.dart',
    filename: 'threaded_comment_sheet.dart',
    category: 'widgets',
    description: 'Threaded comment drawer where authors and users reply directly in-thread.',
    code: `import 'package:flutter/material.dart';
import '../models/models.dart';
import '../utils/formatters.dart';
import 'verification_tick.dart';

class ThreadedCommentSheet extends StatefulWidget {
  final Post post;
  final String currentUserId;
  final VoidCallback onCommentAdded;

  const ThreadedCommentSheet({
    super.key,
    required this.post,
    required this.currentUserId,
    required this.onCommentAdded,
  });

  @override
  State<ThreadedCommentSheet> createState() => _ThreadedCommentSheetState();
}

class _ThreadedCommentSheetState extends State<ThreadedCommentSheet> {
  final TextEditingController _inputController = TextEditingController();
  Comment? _replyingTo;

  void _submitComment() {
    final text = _inputController.text.trim();
    if (text.isEmpty) return;

    final isAuthor = widget.post.author.id == widget.currentUserId;

    final newComment = Comment(
      id: 'cmt_\${DateTime.now().millisecondsSinceEpoch}',
      postId: widget.post.id,
      author: User(
        id: widget.currentUserId,
        name: 'Alex Rivera',
        username: 'alexrivera',
        avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=400',
        creativeField: 'Developer',
        bio: '',
        isTopCreator: true,
      ),
      content: text,
      createdAt: DateTime.now(),
      isAuthorReply: isAuthor && _replyingTo != null,
      replyToUsername: _replyingTo?.author.username,
      replies: [],
    );

    setState(() {
      if (_replyingTo != null) {
        _replyingTo!.replies.add(newComment);
      } else {
        widget.post.comments.add(newComment);
      }
      _replyingTo = null;
      _inputController.clear();
    });

    widget.onCommentAdded();
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(
        bottom: MediaQuery.of(context).viewInsets.bottom,
      ),
      child: SizedBox(
        height: MediaQuery.of(context).size.height * 0.75,
        child: Column(
          children: [
            // Handle bar
            Container(
              margin: const EdgeInsets.symmetric(vertical: 10),
              width: 36,
              height: 4,
              decoration: BoxDecoration(
                color: const Color(0xFF333B4F),
                borderRadius: BorderRadius.circular(2),
              ),
            ),
            // Title
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Text(
                    'Comments',
                    style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Colors.white),
                  ),
                  Text(
                    '\${widget.post.comments.length} total',
                    style: const TextStyle(fontSize: 12, color: Color(0xFF64748B)),
                  ),
                ],
              ),
            ),
            const Divider(color: Color(0xFF1E2330)),

            // Comments List
            Expanded(
              child: widget.post.comments.isEmpty
                  ? const Center(
                      child: Text(
                        'No comments yet. Start the conversation!',
                        style: TextStyle(color: Color(0xFF64748B), fontSize: 13),
                      ),
                    )
                  : ListView.builder(
                      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                      itemCount: widget.post.comments.length,
                      itemBuilder: (ctx, i) => _buildCommentNode(widget.post.comments[i]),
                    ),
            ),

            // Replying Indicator Banner
            if (_replyingTo != null)
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
                color: const Color(0xFF1B202E),
                child: Row(
                  children: [
                    Text(
                      'Replying to @\${_replyingTo!.author.username}',
                      style: const TextStyle(fontSize: 12, color: Color(0xFF38BDF8)),
                    ),
                    const Spacer(),
                    GestureDetector(
                      onTap: () => setState(() => _replyingTo = null),
                      child: const Icon(Icons.close, size: 16, color: Color(0xFF94A3B8)),
                    ),
                  ],
                ),
              ),

            // Input bar
            Container(
              padding: const EdgeInsets.all(12),
              decoration: const BoxDecoration(
                color: Color(0xFF0F1117),
                border: Border(top: BorderSide(color: Color(0xFF1E2330))),
              ),
              child: Row(
                children: [
                  Expanded(
                    child: TextField(
                      controller: _inputController,
                      style: const TextStyle(fontSize: 13, color: Colors.white),
                      decoration: InputDecoration(
                        hintText: _replyingTo != null ? 'Write a reply...' : 'Add a thoughtful comment...',
                        hintStyle: const TextStyle(color: Color(0xFF64748B), fontSize: 13),
                        contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                        filled: true,
                        fillColor: const Color(0xFF1B202E),
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(20),
                          borderSide: BorderSide.none,
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 8),
                  IconButton(
                    onPressed: _submitComment,
                    icon: const Icon(Icons.send_rounded, color: Color(0xFF38BDF8), size: 20),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildCommentNode(Comment comment) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              CircleAvatar(
                radius: 14,
                backgroundImage: NetworkImage(comment.author.avatar),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Text(
                          comment.author.name,
                          style: const TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: Colors.white),
                        ),
                        VerificationTick(type: comment.author.verificationType, size: 12),
                        if (comment.isAuthorReply || comment.author.id == widget.post.author.id)
                          Container(
                            margin: const EdgeInsets.only(left: 6),
                            padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 1),
                            decoration: BoxDecoration(
                              color: const Color(0xFF38BDF8).withOpacity(0.15),
                              borderRadius: BorderRadius.circular(3),
                            ),
                            child: const Text('Author', style: TextStyle(fontSize: 9, color: Color(0xFF38BDF8), fontWeight: FontWeight.bold)),
                          ),
                        const SizedBox(width: 6),
                        Text(
                          ConnectFormatters.formatPostTimestamp(comment.createdAt),
                          style: const TextStyle(fontSize: 10, color: Color(0xFF64748B)),
                        ),
                      ],
                    ),
                    const SizedBox(height: 2),
                    Text(
                      comment.content,
                      style: const TextStyle(fontSize: 13, color: Color(0xFFCBD5E1), height: 1.3),
                    ),
                    const SizedBox(height: 4),
                    GestureDetector(
                      onTap: () {
                        setState(() {
                          _replyingTo = comment;
                        });
                      },
                      child: const Text(
                        'Reply',
                        style: TextStyle(fontSize: 11, fontWeight: FontWeight.w600, color: Color(0xFF38BDF8)),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),

          // Render nested replies
          if (comment.replies.isNotEmpty)
            Padding(
              padding: const EdgeInsets.only(left: 28, top: 8),
              child: Column(
                children: comment.replies.map((reply) => _buildCommentNode(reply)).toList(),
              ),
            ),
        ],
      ),
    );
  }
}
`,
  },
  {
    path: 'lib/screens/feed_screen.dart',
    filename: 'feed_screen.dart',
    category: 'screens',
    description: 'Home Feed screen featuring top header, story carousel, native ad interspersion, and post management.',
    code: `import 'package:flutter/material.dart';
import '../models/models.dart';
import '../widgets/stories_carousel.dart';
import '../widgets/post_card.dart';
import '../widgets/sponsored_ad_card.dart';

class FeedScreen extends StatefulWidget {
  const FeedScreen({super.key});

  @override
  State<FeedScreen> createState() => _FeedScreenState();
}

class _FeedScreenState extends State<FeedScreen> {
  final String _currentUserId = 'current_user';

  late User _currentUser;
  late List<Story> _stories;
  late List<Post> _feedPosts;

  @override
  void initState() {
    super.initState();
    _currentUser = User(
      id: 'current_user',
      name: 'Alex Rivera',
      username: 'alexrivera',
      avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=400',
      creativeField: 'Developer',
      bio: 'Minimalist architectures for low-spec devices.',
      activeUsageHours: 114,
      connectionsCount: 62,
      totalPostViews: 1480,
      isTopCreator: true,
    );

    _stories = [
      Story(
        id: 's1',
        user: _currentUser,
        mediaUrl: 'https://images.unsplash.com/photo-1522071820081-009f0129c71c?w=800',
        caption: 'Optimizing gesture event pipelines.',
        createdAt: DateTime.now().subtract(const Duration(minutes: 30)),
      ),
      Story(
        id: 's2',
        user: User(
          id: 'sarah_c',
          name: 'Sarah Chen',
          username: 'sarahc',
          avatar: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=400',
          creativeField: 'Designer',
          bio: '',
          isTopCreator: true,
        ),
        mediaUrl: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=800',
        createdAt: DateTime.now().subtract(const Duration(hours: 2)),
      ),
    ];

    _feedPosts = [
      Post(
        id: 'p1',
        author: _currentUser,
        content: 'Deployed the gesture handler for Connect! Tap once for a calm blue heart; double-tap for the red Super Like animation.',
        createdAt: DateTime.now().subtract(const Duration(minutes: 25)), // Within 1-hour editable window!
        likesCount: 24,
        superLikesCount: 11,
        viewsCount: 312,
        sharesCount: 8,
        comments: [],
      ),
      Post(
        id: 'ad_nordic',
        author: User(
          id: 'nordic',
          name: 'Nordic Sound Labs',
          username: 'nordicaudio',
          avatar: 'https://images.unsplash.com/photo-1546435770-a3e426bf472b?w=200',
          creativeField: 'Sound Architect',
          bio: '',
        ),
        content: 'Reference One Studio Monitors. Ultra-flat response engineered for bedroom producers and sound architects.',
        isSponsored: true,
        sponsoredData: SponsoredAdData(
          companyName: 'Nordic Sound Labs',
          companyLogo: 'https://images.unsplash.com/photo-1546435770-a3e426bf472b?w=200',
          format: 'photo',
          mediaUrl: 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=800',
          headline: 'Acoustic Clarity',
          ctaText: 'Explore Gear',
          ctaUrl: 'https://connect.social/partner/nordic-sound',
        ),
        createdAt: DateTime.now().subtract(const Duration(days: 1)),
        likesCount: 156,
        viewsCount: 2420,
        sharesCount: 44,
        comments: [],
      ),
      Post(
        id: 'p2',
        author: User(
          id: 'marcus_v',
          name: 'Marcus Vance',
          username: 'marcusv',
          avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400',
          creativeField: 'Writer',
          bio: '',
          activeUsageHours: 110,
        ),
        content: 'Why "Connect" matters: Following is passive watching. Connecting implies mutual recognition, shared frequency, and exchange.',
        createdAt: DateTime.now().subtract(const Duration(days: 1)),
        likesCount: 204,
        superLikesCount: 97,
        viewsCount: 1870,
        sharesCount: 63,
        comments: [],
      ),
    ];
  }

  void _showCreatePostDialog() {
    final textController = TextEditingController();
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: const Color(0xFF1B202E),
        title: const Text('Create Post', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
        content: TextField(
          controller: textController,
          maxLines: 4,
          style: const TextStyle(fontSize: 14, color: Colors.white),
          decoration: InputDecoration(
            hintText: 'Share a thought, concept, or update...',
            hintStyle: const TextStyle(color: Color(0xFF64748B)),
            filled: true,
            fillColor: const Color(0xFF13161F),
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: BorderSide.none),
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF38BDF8), foregroundColor: Colors.black),
            onPressed: () {
              if (textController.text.trim().isNotEmpty) {
                setState(() {
                  _feedPosts.insert(
                    0,
                    Post(
                      id: 'p_\${DateTime.now().millisecondsSinceEpoch}',
                      author: _currentUser,
                      content: textController.text.trim(),
                      createdAt: DateTime.now(),
                      comments: [],
                    ),
                  );
                });
              }
              Navigator.pop(ctx);
            },
            child: const Text('Post'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Connect',
          style: TextStyle(
            fontSize: 22,
            fontWeight: FontWeight.w800,
            letterSpacing: -0.8,
            color: Color(0xFF38BDF8),
          ),
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.add_circle_outline_rounded, color: Color(0xFF38BDF8), size: 24),
            onPressed: _showCreatePostDialog,
          ),
          IconButton(
            icon: const Icon(Icons.notifications_none_rounded, color: Color(0xFF94A3B8), size: 22),
            onPressed: () {},
          ),
        ],
      ),
      body: RefreshIndicator(
        color: const Color(0xFF38BDF8),
        backgroundColor: const Color(0xFF1B202E),
        onRefresh: () async {
          await Future.delayed(const Duration(milliseconds: 600));
          setState(() {});
        },
        child: ListView(
          physics: const AlwaysScrollableScrollPhysics(),
          children: [
            // Stories Row / Carousel
            StoriesCarousel(
              stories: _stories,
              currentUser: _currentUser,
              onStoryTap: (story) {},
              onAddStory: () {},
            ),

            // Posts & Interspersed Ads
            ..._feedPosts.map((post) {
              if (post.isSponsored) {
                return SponsoredAdCard(post: post);
              }
              return PostCard(
                post: post,
                currentUserId: _currentUserId,
                onUpdate: (updated) {
                  setState(() {});
                },
                onDelete: (deletedId) {
                  setState(() {
                    _feedPosts.removeWhere((p) => p.id == deletedId);
                  });
                },
              );
            }),
          ],
        ),
      ),
    );
  }
}
`,
  },
  {
    path: 'lib/screens/profile_screen.dart',
    filename: 'profile_screen.dart',
    category: 'screens',
    description: 'Profile section with avatar upload, Creative Field tags, dynamic verification ticks, Connect button, achievements, and 3-dots menu.',
    code: `import 'package:flutter/material.dart';
import '../models/models.dart';
import '../widgets/verification_tick.dart';
import 'insights_screen.dart';

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  late User _profileUser;
  late List<Achievement> _achievements;

  @override
  void initState() {
    super.initState();
    _profileUser = User(
      id: 'current_user',
      name: 'Alex Rivera',
      username: 'alexrivera',
      avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=400',
      creativeField: 'Developer',
      bio: 'Building minimal, lightning-fast mobile architectures. Open source enthusiast and UI systems explorer.',
      activeUsageHours: 114,
      connectionsCount: 62,
      totalPostViews: 1480,
      isTopCreator: true,
      connectionStatus: 'connected',
    );

    _achievements = [
      Achievement(
        id: 'ach_hours',
        title: 'Centurion of Focus',
        description: '100+ active hours. Unlocks Blue Verification Tick.',
        icon: Icons.verified_user_outlined,
        currentProgress: 114,
        targetProgress: 100,
        isUnlocked: true,
        unlockedAt: 'Oct 28',
      ),
      Achievement(
        id: 'ach_conn',
        title: 'Community Architect',
        description: '50+ mutual connections. Unlocks Yellow Tick.',
        icon: Icons.people_alt_outlined,
        currentProgress: 62,
        targetProgress: 50,
        isUnlocked: true,
        unlockedAt: 'Oct 30',
      ),
      Achievement(
        id: 'ach_creator',
        title: 'Collaborative Vanguard',
        description: '1,000+ views & top creator status. Unlocks Red Tick.',
        icon: Icons.auto_awesome_rounded,
        currentProgress: 1480,
        targetProgress: 1000,
        isUnlocked: true,
        unlockedAt: 'Oct 31',
      ),
      Achievement(
        id: 'ach_super',
        title: 'Super Resonator',
        description: 'Give 50 Super Likes to elevate standout creations.',
        icon: Icons.local_fire_department_outlined,
        currentProgress: 38,
        targetProgress: 50,
        isUnlocked: false,
      ),
    ];
  }

  void _showThreeDotMenu() {
    showModalBottomSheet(
      context: context,
      backgroundColor: const Color(0xFF13161F),
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (ctx) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              margin: const EdgeInsets.symmetric(vertical: 8),
              width: 36,
              height: 4,
              decoration: BoxDecoration(color: const Color(0xFF333B4F), borderRadius: BorderRadius.circular(2)),
            ),
            ListTile(
              leading: const Icon(Icons.settings_outlined, color: Colors.white),
              title: const Text('Settings', style: TextStyle(fontSize: 14, color: Colors.white)),
              onTap: () => Navigator.pop(ctx),
            ),
            ListTile(
              leading: const Icon(Icons.bar_chart_rounded, color: Color(0xFF38BDF8)),
              title: const Text('Post Insights & Analytics', style: TextStyle(fontSize: 14, color: Colors.white)),
              onTap: () {
                Navigator.pop(ctx);
                Navigator.push(context, MaterialPageRoute(builder: (_) => const InsightsScreen()));
              },
            ),
            ListTile(
              leading: const Icon(Icons.military_tech_outlined, color: Colors.amber),
              title: const Text('Achievements & Level Status', style: TextStyle(fontSize: 14, color: Colors.white)),
              onTap: () => Navigator.pop(ctx),
            ),
            ListTile(
              leading: const Icon(Icons.privacy_tip_outlined, color: Colors.white),
              title: const Text('Privacy Policy', style: TextStyle(fontSize: 14, color: Colors.white)),
              onTap: () => Navigator.pop(ctx),
            ),
            ListTile(
              leading: const Icon(Icons.info_outline_rounded, color: Colors.white),
              title: const Text('About Us', style: TextStyle(fontSize: 14, color: Colors.white)),
              onTap: () => Navigator.pop(ctx),
            ),
            const Divider(color: Color(0xFF1E2330)),
            ListTile(
              leading: const Icon(Icons.logout_rounded, color: Color(0xFFEF4444)),
              title: const Text('Sign Out / Logout', style: TextStyle(color: Color(0xFFEF4444), fontSize: 14)),
              onTap: () => Navigator.pop(ctx),
            ),
          ],
        ),
      ),
    );
  }

  void _toggleConnect() {
    setState(() {
      if (_profileUser.connectionStatus == 'connect') {
        _profileUser.connectionStatus = 'pending';
      } else if (_profileUser.connectionStatus == 'pending') {
        _profileUser.connectionStatus = 'connected';
      } else {
        _profileUser.connectionStatus = 'connect';
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Profile'),
        actions: [
          IconButton(
            icon: const Icon(Icons.more_vert_rounded),
            onPressed: _showThreeDotMenu,
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.symmetric(horizontal: 16),
        children: [
          const SizedBox(height: 12),

          // Profile Header
          Row(
            children: [
              Stack(
                children: [
                  CircleAvatar(
                    radius: 40,
                    backgroundImage: NetworkImage(_profileUser.avatar),
                  ),
                  Positioned(
                    bottom: 0,
                    right: 0,
                    child: Container(
                      width: 26,
                      height: 26,
                      decoration: const BoxDecoration(
                        color: Color(0xFF38BDF8),
                        shape: BoxShape.circle,
                      ),
                      child: const Icon(Icons.edit, size: 14, color: Colors.black),
                    ),
                  ),
                ],
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Text(
                          _profileUser.name,
                          style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.white),
                        ),
                        VerificationTick(type: _profileUser.verificationType, size: 16),
                      ],
                    ),
                    Text(
                      '@\${_profileUser.username}',
                      style: const TextStyle(fontSize: 13, color: Color(0xFF64748B)),
                    ),
                    const SizedBox(height: 6),
                    // Creative Field Tag
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 3),
                      decoration: BoxDecoration(
                        color: const Color(0xFF1B202E),
                        borderRadius: BorderRadius.circular(6),
                        border: Border.all(color: const Color(0xFF333B4F)),
                      ),
                      child: Text(
                        _profileUser.creativeField,
                        style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w600, color: Color(0xFF38BDF8)),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),

          const SizedBox(height: 16),

          // Bio
          Text(
            _profileUser.bio,
            style: const TextStyle(fontSize: 13, color: Color(0xFFCBD5E1), height: 1.4),
          ),

          const SizedBox(height: 16),

          // Metric Stats Counter
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              _buildMetricCol('Hours Active', '\${_profileUser.activeUsageHours}h'),
              _buildMetricCol('Connections', '\${_profileUser.connectionsCount}'),
              _buildMetricCol('Post Views', '\${_profileUser.totalPostViews}'),
            ],
          ),

          const SizedBox(height: 16),

          // "Connect" Button
          SizedBox(
            width: double.infinity,
            child: ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: _profileUser.connectionStatus == 'connected'
                    ? const Color(0xFF1B202E)
                    : const Color(0xFF38BDF8),
                foregroundColor: _profileUser.connectionStatus == 'connected' ? Colors.white : Colors.black,
                padding: const EdgeInsets.symmetric(vertical: 12),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
              ),
              onPressed: _toggleConnect,
              child: Text(
                _profileUser.connectionStatus == 'connected'
                    ? 'Connected'
                    : _profileUser.connectionStatus == 'pending'
                        ? 'Pending...'
                        : 'Connect',
                style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14),
              ),
            ),
          ),

          const SizedBox(height: 24),

          // Achievements Section Header
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text(
                'Achievements & Milestones',
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Colors.white),
              ),
              Text(
                '\${_achievements.where((a) => a.isUnlocked).length}/\${_achievements.length} Earned',
                style: const TextStyle(fontSize: 12, color: Color(0xFF38BDF8)),
              ),
            ],
          ),

          const SizedBox(height: 12),

          // Dedicated Scrollable Achievements List
          SizedBox(
            height: 130,
            child: ListView.separated(
              scrollDirection: Axis.horizontal,
              itemCount: _achievements.length,
              separatorBuilder: (_, __) => const SizedBox(width: 12),
              itemBuilder: (ctx, i) {
                final ach = _achievements[i];
                return Container(
                  width: 220,
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: const Color(0xFF13161F),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(
                      color: ach.isUnlocked ? const Color(0xFF38BDF8).withOpacity(0.4) : const Color(0xFF1E2330),
                    ),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Icon(ach.icon, color: ach.isUnlocked ? const Color(0xFF38BDF8) : Colors.grey, size: 20),
                          const Spacer(),
                          if (ach.isUnlocked)
                            const Text('UNLOCKED', style: TextStyle(fontSize: 9, color: Color(0xFF38BDF8), fontWeight: FontWeight.bold)),
                        ],
                      ),
                      const SizedBox(height: 6),
                      Text(ach.title, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.bold, color: Colors.white)),
                      Text(ach.description, style: const TextStyle(fontSize: 10, color: Color(0xFF94A3B8)), maxLines: 2, overflow: TextOverflow.ellipsis),
                      const Spacer(),
                      LinearProgressIndicator(
                        value: (ach.currentProgress / ach.targetProgress).clamp(0.0, 1.0),
                        backgroundColor: const Color(0xFF1E2330),
                        valueColor: const AlwaysStoppedAnimation(Color(0xFF38BDF8)),
                      ),
                    ],
                  ),
                );
              },
            ),
          ),

          const SizedBox(height: 32),
        ],
      ),
    );
  }

  Widget _buildMetricCol(String label, String value) {
    return Column(
      children: [
        Text(value, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.white)),
        const SizedBox(height: 2),
        Text(label, style: const TextStyle(fontSize: 11, color: Color(0xFF64748B))),
      ],
    );
  }
}
`,
  },
  {
    path: 'lib/screens/insights_screen.dart',
    filename: 'insights_screen.dart',
    category: 'screens',
    description: 'Post Insights and engagement analytics for creator posts.',
    code: `import 'package:flutter/material.dart';

class InsightsScreen extends StatelessWidget {
  const InsightsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Post Insights')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          // Total Impressions Card
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: const Color(0xFF13161F),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: const Color(0xFF1E2330)),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('Total Post Impressions', style: TextStyle(color: Color(0xFF94A3B8), fontSize: 13)),
                const SizedBox(height: 6),
                const Text('1,480', style: TextStyle(color: Colors.white, fontSize: 28, fontWeight: FontWeight.bold)),
                const SizedBox(height: 4),
                Row(
                  children: const [
                    Icon(Icons.arrow_upward_rounded, color: Color(0xFF10B981), size: 14),
                    SizedBox(width: 4),
                    Text('+28.4% this week', style: TextStyle(color: Color(0xFF10B981), fontSize: 12, fontWeight: FontWeight.w600)),
                  ],
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),
          // Like vs Super Like breakdown
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: const Color(0xFF13161F),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: const Color(0xFF1E2330)),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: const [
                Text('Engagement Breakdown', style: TextStyle(color: Colors.white, fontSize: 15, fontWeight: FontWeight.bold)),
                SizedBox(height: 12),
                ListTile(
                  contentPadding: EdgeInsets.zero,
                  leading: Icon(Icons.favorite, color: Color(0xFF38BDF8)),
                  title: Text('Standard Likes (Blue)', style: TextStyle(fontSize: 13, color: Colors.white)),
                  trailing: Text('312', style: TextStyle(fontWeight: FontWeight.bold, color: Colors.white)),
                ),
                ListTile(
                  contentPadding: EdgeInsets.zero,
                  leading: Icon(Icons.favorite, color: Color(0xFFEF4444)),
                  title: Text('Super Likes (Red Burst)', style: TextStyle(fontSize: 13, color: Colors.white)),
                  trailing: Text('148', style: TextStyle(fontWeight: FontWeight.bold, color: Color(0xFFEF4444))),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
`,
  },
  {
    path: 'lib/screens/messages_screen.dart',
    filename: 'messages_screen.dart',
    category: 'screens',
    description: 'Messages and Inbox view for direct conversations between connected creators.',
    code: `import 'package:flutter/material.dart';

class MessagesScreen extends StatelessWidget {
  const MessagesScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Messages'),
        actions: [
          IconButton(
            icon: const Icon(Icons.edit_square, color: Color(0xFF38BDF8), size: 20),
            onPressed: () {},
          ),
        ],
      ),
      body: ListView(
        children: [
          _buildConversationTile(
            avatar: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=400',
            name: 'Sarah Chen',
            message: 'The double tap animation is running super smooth!',
            time: '14:28',
            unread: 1,
          ),
          _buildConversationTile(
            avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400',
            name: 'Marcus Vance',
            message: 'Would love to co-author an essay on the Connect model.',
            time: 'Yesterday',
            unread: 0,
          ),
        ],
      ),
    );
  }

  Widget _buildConversationTile({
    required String avatar,
    required String name,
    required String message,
    required String time,
    required int unread,
  }) {
    return Container(
      decoration: const BoxDecoration(
        border: Border(bottom: BorderSide(color: Color(0xFF1E2330), width: 0.8)),
      ),
      child: ListTile(
        leading: CircleAvatar(backgroundImage: NetworkImage(avatar), radius: 22),
        title: Text(name, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14, color: Colors.white)),
        subtitle: Text(message, style: const TextStyle(color: Color(0xFF94A3B8), fontSize: 12), overflow: TextOverflow.ellipsis),
        trailing: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            Text(time, style: const TextStyle(color: Color(0xFF64748B), fontSize: 11)),
            if (unread > 0)
              Container(
                margin: const EdgeInsets.only(top: 4),
                padding: const EdgeInsets.all(5),
                decoration: const BoxDecoration(color: Color(0xFF38BDF8), shape: BoxShape.circle),
                child: Text(unread.toString(), style: const TextStyle(color: Colors.black, fontSize: 9, fontWeight: FontWeight.bold)),
              ),
          ],
        ),
      ),
    );
  }
}
`,
  },
];
