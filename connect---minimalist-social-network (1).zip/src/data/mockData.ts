import { User, Post, Story, Achievement, Conversation } from '../types';

// The currently logged-in user profile
export const CURRENT_USER: User = {
  id: 'current_user',
  name: 'Alex Rivera',
  username: 'alexrivera',
  avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=400&auto=format&fit=crop&q=80',
  creativeField: 'Developer',
  bio: 'Building minimal, lightning-fast mobile architectures. Open source enthusiast and UI systems explorer.',
  stats: {
    activeUsageHours: 114, // >= 100 -> Blue Tick unlocked!
    connectionsCount: 62,  // >= 50 -> Yellow Tick community milestone unlocked!
    totalPostViews: 1480,  // >= 1000 views + milestones -> Red Tick eligible!
    isTopCreator: true,
  },
  connectionStatus: 'connected',
};

// Other network creators
export const CREATOR_SARAH: User = {
  id: 'sarah_chen',
  name: 'Sarah Chen',
  username: 'sarahc',
  avatar: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=400&auto=format&fit=crop&q=80',
  creativeField: 'Designer',
  bio: 'Interaction design lead & typography minimalist. Crafting systems that delight quietly.',
  stats: {
    activeUsageHours: 140,
    connectionsCount: 88,
    totalPostViews: 3200,
    isTopCreator: true,
  },
  connectionStatus: 'connected',
};

export const CREATOR_MARCUS: User = {
  id: 'marcus_vance',
  name: 'Marcus Vance',
  username: 'marcusv',
  avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&auto=format&fit=crop&q=80',
  creativeField: 'Writer',
  bio: 'Essayist on computational poetry, ambient computing, and human connection.',
  stats: {
    activeUsageHours: 102,
    connectionsCount: 34, // Blue tick (hours > 100)
    totalPostViews: 850,
    isTopCreator: false,
  },
  connectionStatus: 'connect',
};

export const CREATOR_ELENA: User = {
  id: 'elena_rostova',
  name: 'Elena Rostova',
  username: 'elenarostova',
  avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=400&auto=format&fit=crop&q=80',
  creativeField: 'Generalist',
  bio: 'Exploring intersections of spatial audio, generative synthesis, and organic architecture.',
  stats: {
    activeUsageHours: 45,
    connectionsCount: 54, // Yellow tick (connections >= 50)
    totalPostViews: 640,
    isTopCreator: false,
  },
  connectionStatus: 'connect',
};

export const CREATOR_DEVON: User = {
  id: 'devon_lane',
  name: 'Devon Lane',
  username: 'devon_arch',
  avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=400&auto=format&fit=crop&q=80',
  creativeField: 'Sound Architect',
  bio: 'Synthesizing organic textures for minimalist ambient soundscapes.',
  stats: {
    activeUsageHours: 35,
    connectionsCount: 18,
    totalPostViews: 220,
    isTopCreator: false,
  },
  connectionStatus: 'pending',
};

// Calculate dates relative to today
const now = new Date();

// Post 1: Created 20 minutes ago (Today -> shows exact time e.g. 14:15, editable because < 1h)
const date20MinAgo = new Date(now.getTime() - 20 * 60 * 1000);

// Post 2: Created 3 hours ago (Today -> shows exact time, but editing locked because > 1h)
const date3HoursAgo = new Date(now.getTime() - 3 * 60 * 60 * 1000);

// Post 3: Created Yesterday
const dateYesterday = new Date(now.getTime() - 26 * 60 * 60 * 1000);

// Post 4: Created 3 days ago
const date3DaysAgo = new Date(now.getTime() - 72 * 60 * 60 * 1000);

// Initial Stories
export const INITIAL_STORIES: Story[] = [
  {
    id: 's_user',
    user: CURRENT_USER,
    mediaUrl: 'https://images.unsplash.com/photo-1522071820081-009f0129c71c?w=800&auto=format&fit=crop&q=80',
    caption: 'Late night refactor of the rendering pipeline ⚡️',
    createdAt: date20MinAgo.toISOString(),
    isViewed: false,
  },
  {
    id: 's1',
    user: CREATOR_SARAH,
    mediaUrl: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=800&auto=format&fit=crop&q=80',
    caption: 'New visual language exploration for Connect v2.',
    createdAt: date3HoursAgo.toISOString(),
    isViewed: false,
  },
  {
    id: 's2',
    user: CREATOR_MARCUS,
    mediaUrl: 'https://images.unsplash.com/photo-1516962215378-7fa2e137ae93?w=800&auto=format&fit=crop&q=80',
    caption: 'Morning notes on typography rhythm and white space.',
    createdAt: dateYesterday.toISOString(),
    isViewed: false,
  },
  {
    id: 's3',
    user: CREATOR_ELENA,
    mediaUrl: 'https://images.unsplash.com/photo-1508700115892-45ecd05ae2ad?w=800&auto=format&fit=crop&q=80',
    caption: 'Field recording in Kyoto. Subtle water frequency.',
    createdAt: dateYesterday.toISOString(),
    isViewed: true,
  },
  {
    id: 's4',
    user: CREATOR_DEVON,
    mediaUrl: 'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=800&auto=format&fit=crop&q=80',
    caption: 'Analog synthesizer modular rig setup.',
    createdAt: date3DaysAgo.toISOString(),
    isViewed: true,
  },
];

// Initial Feed Posts
export const INITIAL_POSTS: Post[] = [
  {
    id: 'p1',
    author: CURRENT_USER,
    content: 'Just deployed the new custom gesture handler for Connect! Single tap gives a calm blue heart, and double-tapping launches a super-charged red super like animation. Built with 60fps budget for low-spec mobile chips.',
    createdAt: date20MinAgo.toISOString(),
    likesCount: 24,
    superLikesCount: 11,
    userLikeState: 'none',
    viewsCount: 312,
    sharesCount: 9,
    comments: [
      {
        id: 'c1',
        postId: 'p1',
        author: {
          id: CREATOR_SARAH.id,
          name: CREATOR_SARAH.name,
          username: CREATOR_SARAH.username,
          avatar: CREATOR_SARAH.avatar,
          creativeField: CREATOR_SARAH.creativeField,
          verification: 'red',
        },
        content: 'The micro-haptic visual feedback on the double tap feels so crisp! What animation curve did you use?',
        createdAt: new Date(date20MinAgo.getTime() + 5 * 60 * 1000).toISOString(),
        replies: [
          {
            id: 'c1_r1',
            postId: 'p1',
            author: {
              id: CURRENT_USER.id,
              name: CURRENT_USER.name,
              username: CURRENT_USER.username,
              avatar: CURRENT_USER.avatar,
              creativeField: CURRENT_USER.creativeField,
              verification: 'red',
            },
            content: 'Used a spring curve (damping 12, stiffness 180) with a quick 0.8x -> 1.35x scale bounce. Smooth even on 2GB RAM phones!',
            createdAt: new Date(date20MinAgo.getTime() + 8 * 60 * 1000).toISOString(),
            isAuthorReply: true,
            replyToUsername: 'sarahc',
          },
        ],
      },
    ],
  },
  {
    id: 'p2',
    author: CREATOR_SARAH,
    content: 'Whitespace is not empty space; it is the visual oxygen that allows typographic elements to breathe. Minimalist design prioritizes cognitive clarity over ornamental decoration.',
    image: 'https://images.unsplash.com/photo-1507238691740-187a5b1d37b8?w=800&auto=format&fit=crop&q=80',
    createdAt: date3HoursAgo.toISOString(),
    likesCount: 88,
    superLikesCount: 42,
    userLikeState: 'blue',
    viewsCount: 940,
    sharesCount: 31,
    comments: [
      {
        id: 'c2',
        postId: 'p2',
        author: {
          id: CREATOR_MARCUS.id,
          name: CREATOR_MARCUS.name,
          username: CREATOR_MARCUS.username,
          avatar: CREATOR_MARCUS.avatar,
          creativeField: CREATOR_MARCUS.creativeField,
          verification: 'blue',
        },
        content: 'Spot on Sarah. When every element demands attention, nothing gets heard.',
        createdAt: new Date(date3HoursAgo.getTime() + 15 * 60 * 1000).toISOString(),
        replies: [],
      },
    ],
  },
  {
    id: 'p_ad1',
    author: {
      id: 'nordic_audio',
      name: 'Nordic Sound Labs',
      username: 'nordicaudio',
      avatar: 'https://images.unsplash.com/photo-1546435770-a3e426bf472b?w=200&auto=format&fit=crop&q=80',
      creativeField: 'Sound Architect',
      bio: 'High fidelity acoustic monitors tuned for creators.',
      stats: { activeUsageHours: 200, connectionsCount: 1500, totalPostViews: 85000, isTopCreator: true },
      connectionStatus: 'connect',
    },
    content: 'Meet the Reference One monitors. Ultra-flat frequency response engineered for bedroom producers and sound architects who value precision over artificial bass boosts.',
    isSponsored: true,
    sponsoredData: {
      companyName: 'Nordic Sound Labs',
      companyLogo: 'https://images.unsplash.com/photo-1546435770-a3e426bf472b?w=200&auto=format&fit=crop&q=80',
      format: 'photo',
      mediaUrl: 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=800&auto=format&fit=crop&q=80',
      headline: 'Acoustic Clarity for Creators',
      ctaText: 'Explore Gear',
      ctaUrl: 'https://connect.social/partner/nordic-sound',
    },
    createdAt: dateYesterday.toISOString(),
    likesCount: 156,
    superLikesCount: 38,
    userLikeState: 'none',
    viewsCount: 2420,
    sharesCount: 44,
    comments: [
      {
        id: 'c_ad_1',
        postId: 'p_ad1',
        author: {
          id: CREATOR_DEVON.id,
          name: CREATOR_DEVON.name,
          username: CREATOR_DEVON.username,
          avatar: CREATOR_DEVON.avatar,
          creativeField: CREATOR_DEVON.creativeField,
          verification: 'none',
        },
        content: 'Are these compatible with USB-C DAC output directly?',
        createdAt: new Date(dateYesterday.getTime() + 45 * 60 * 1000).toISOString(),
        replies: [
          {
            id: 'c_ad_r1',
            postId: 'p_ad1',
            author: {
              id: 'nordic_audio',
              name: 'Nordic Sound Labs',
              username: 'nordicaudio',
              avatar: 'https://images.unsplash.com/photo-1546435770-a3e426bf472b?w=200&auto=format&fit=crop&q=80',
              creativeField: 'Sound Architect',
              verification: 'red',
            },
            content: 'Yes! High-res 32-bit/384kHz internal DAC accepts direct USB-C input from phones, laptops, and tablets.',
            createdAt: new Date(dateYesterday.getTime() + 55 * 60 * 1000).toISOString(),
            isAuthorReply: true,
            replyToUsername: 'devon_arch',
          },
        ],
      },
    ],
  },
  {
    id: 'p3',
    author: CREATOR_MARCUS,
    content: 'Why is the word "Connect" so much more intentional than "Follow"? Following implies passive consumption from behind. Connecting implies reciprocity, exchange, and two minds finding common frequency.',
    createdAt: dateYesterday.toISOString(),
    likesCount: 204,
    superLikesCount: 97,
    userLikeState: 'red',
    viewsCount: 1870,
    sharesCount: 63,
    comments: [],
  },
  {
    id: 'p4',
    author: CREATOR_ELENA,
    content: 'Reflecting on creative fields: being labeled a "Generalist" used to feel like a compromise. In 2026, the synthesis of disciplines is where genuine innovation happens. Connecting dots between engineering and aesthetics is the ultimate super-skill.',
    image: 'https://images.unsplash.com/photo-1451187580459-43490279c0fa?w=800&auto=format&fit=crop&q=80',
    createdAt: date3DaysAgo.toISOString(),
    likesCount: 312,
    superLikesCount: 145,
    userLikeState: 'none',
    viewsCount: 2980,
    sharesCount: 88,
    comments: [],
  },
];

// Initial Achievements
export const INITIAL_ACHIEVEMENTS: Achievement[] = [
  {
    id: 'ach_100_hours',
    title: 'Centurion of Focus',
    description: 'Active for 100+ hours in Connect. Unlocks the prestigious Blue Verification Tick.',
    icon: 'ShieldCheck',
    category: 'hours',
    currentProgress: 114,
    targetProgress: 100,
    isUnlocked: true,
    unlockedAt: 'Oct 28, 2026',
  },
  {
    id: 'ach_50_connections',
    title: 'Community Architect',
    description: 'Establish 50 mutual creator connections. Unlocks the Yellow Community Tick.',
    icon: 'Users',
    category: 'connections',
    currentProgress: 62,
    targetProgress: 50,
    isUnlocked: true,
    unlockedAt: 'Oct 30, 2026',
  },
  {
    id: 'ach_top_creator',
    title: 'Collaborative Vanguard',
    description: 'Achieve 1,000+ views and top creator standing. Unlocks the Red Elite Verification Tick.',
    icon: 'Sparkles',
    category: 'creator',
    currentProgress: 1480,
    targetProgress: 1000,
    isUnlocked: true,
    unlockedAt: 'Oct 31, 2026',
  },
  {
    id: 'ach_super_liker',
    title: 'Super Resonator',
    description: 'Give 50 Super Likes to elevate standout community creations.',
    icon: 'Flame',
    category: 'engagement',
    currentProgress: 38,
    targetProgress: 50,
    isUnlocked: false,
  },
  {
    id: 'ach_discussion_leader',
    title: 'Thread Weaver',
    description: 'Author 25 threaded discussions with active multi-turn replies.',
    icon: 'MessageSquareText',
    category: 'engagement',
    currentProgress: 18,
    targetProgress: 25,
    isUnlocked: false,
  },
  {
    id: 'ach_minimalist_streak',
    title: 'Daily Resonance',
    description: 'Open and interact with Connect for 14 consecutive days.',
    icon: 'Zap',
    category: 'hours',
    currentProgress: 12,
    targetProgress: 14,
    isUnlocked: false,
  },
];

// Initial Direct Messages
export const INITIAL_CONVERSATIONS: Conversation[] = [
  {
    id: 'conv_1',
    user: CREATOR_SARAH,
    lastMessage: 'The double tap animation is running super smooth!',
    lastTime: '14:28',
    unreadCount: 1,
    messages: [
      {
        id: 'm1',
        senderId: CREATOR_SARAH.id,
        text: 'Hey Alex! Did you manage to test on an older Android device?',
        timestamp: '14:10',
      },
      {
        id: 'm2',
        senderId: CURRENT_USER.id,
        text: 'Yes! Runs at 60fps locked. The state transitions are completely decoupled.',
        timestamp: '14:16',
      },
      {
        id: 'm3',
        senderId: CREATOR_SARAH.id,
        text: 'The double tap animation is running super smooth!',
        timestamp: '14:28',
      },
    ],
  },
  {
    id: 'conv_2',
    user: CREATOR_MARCUS,
    lastMessage: 'Would love to co-author an essay on the Connect model.',
    lastTime: 'Yesterday',
    unreadCount: 0,
    messages: [
      {
        id: 'm4',
        senderId: CREATOR_MARCUS.id,
        text: 'Would love to co-author an essay on the Connect model.',
        timestamp: 'Yesterday 17:30',
      },
    ],
  },
  {
    id: 'conv_3',
    user: CREATOR_ELENA,
    lastMessage: 'Just saw your new post about gesture systems.',
    lastTime: 'Oct 29',
    unreadCount: 0,
    messages: [
      {
        id: 'm5',
        senderId: CREATOR_ELENA.id,
        text: 'Just saw your new post about gesture systems.',
        timestamp: 'Oct 29 11:20',
      },
    ],
  },
];
